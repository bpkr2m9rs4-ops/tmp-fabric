#!/usr/bin/env bash
# Generates MSPs/TLS certs (cryptogen, no CA) and the channel genesis block (configtxgen).
# TLS certs carry SANs for 127.0.0.1 AND the GNS3 IPs, so the same crypto works in both modes.
# Copy $RUNTIME/crypto (+ artifacts) to every GNS3 node afterwards (or at least that node's own dirs).
set -euo pipefail
. "$(dirname "$0")/network.env"
mkdir -p "$RUNTIME/artifacts"; cd "$RUNTIME"
rm -rf crypto artifacts/*

cat > crypto-config.yaml <<YAML
OrdererOrgs:
  - Name: Orderer
    Domain: example.com
    EnableNodeOUs: true
    Specs:
      - Hostname: orderer
        SANS: [localhost, 127.0.0.1, 192.168.10.11]
PeerOrgs:
YAML
for n in 1 2 3; do
  case $n in 1) ip=192.168.10.12;; 2) ip=192.168.10.13;; 3) ip=192.168.10.14;; esac
  cat >> crypto-config.yaml <<YAML
  - Name: Org$n
    Domain: org$n.example.com
    EnableNodeOUs: true
    Template:
      Count: 1
      SANS: [localhost, 127.0.0.1, $ip]
    Users:
      Count: 3
YAML
done
cryptogen generate --config=crypto-config.yaml --output=crypto

# configtx: three application orgs (anchor peers declared => cross-org gossip/discovery works), 1 Raft consenter.
O_TLS="$ORDERER_DIR/tls/server.crt"
cat > configtx.yaml <<YAML
Organizations:
  - &Orderer
    Name: OrdererOrg
    ID: OrdererMSP
    MSPDir: $CRYPTO/ordererOrganizations/example.com/msp
    Policies:
      Readers: {Type: Signature, Rule: "OR('OrdererMSP.member')"}
      Writers: {Type: Signature, Rule: "OR('OrdererMSP.member')"}
      Admins:  {Type: Signature, Rule: "OR('OrdererMSP.admin')"}
    OrdererEndpoints: ["$ORDERER_IP:$ORDERER_PORT"]
YAML
for n in 1 2 3; do
cat >> configtx.yaml <<YAML
  - &Org$n
    Name: Org${n}MSP
    ID: Org${n}MSP
    MSPDir: $(ORG_MSP_DIR $n)/msp
    Policies:
      Readers:     {Type: Signature, Rule: "OR('Org${n}MSP.admin','Org${n}MSP.peer','Org${n}MSP.client')"}
      Writers:     {Type: Signature, Rule: "OR('Org${n}MSP.admin','Org${n}MSP.client')"}
      Admins:      {Type: Signature, Rule: "OR('Org${n}MSP.admin')"}
      Endorsement: {Type: Signature, Rule: "OR('Org${n}MSP.peer')"}
    AnchorPeers:
      - {Host: ${PEER_IP[$n]}, Port: ${PEER_PORT[$n]}}
YAML
done
cat >> configtx.yaml <<YAML
Capabilities:
  Channel: &ChannelCaps {V2_0: true}
  Orderer: &OrdererCaps {V2_0: true}
  Application: &AppCaps {V2_5: true}
Application: &AppDefaults
  Organizations:
  Policies:
    Readers: {Type: ImplicitMeta, Rule: "ANY Readers"}
    Writers: {Type: ImplicitMeta, Rule: "ANY Writers"}
    Admins: {Type: ImplicitMeta, Rule: "MAJORITY Admins"}
    LifecycleEndorsement: {Type: ImplicitMeta, Rule: "MAJORITY Endorsement"}
    Endorsement: {Type: ImplicitMeta, Rule: "MAJORITY Endorsement"}
  Capabilities: *AppCaps
Orderer: &OrdererDefaults
  OrdererType: etcdraft
  Addresses: ["$ORDERER_IP:$ORDERER_PORT"]
  EtcdRaft:
    Consenters:
      - {Host: $ORDERER_IP, Port: $ORDERER_PORT, ClientTLSCert: $O_TLS, ServerTLSCert: $O_TLS}
  BatchTimeout: 1s
  BatchSize: {MaxMessageCount: 20, AbsoluteMaxBytes: 99 MB, PreferredMaxBytes: 512 KB}
  Organizations:
  Policies:
    Readers: {Type: ImplicitMeta, Rule: "ANY Readers"}
    Writers: {Type: ImplicitMeta, Rule: "ANY Writers"}
    Admins: {Type: ImplicitMeta, Rule: "MAJORITY Admins"}
    BlockValidation: {Type: ImplicitMeta, Rule: "ANY Writers"}
  Capabilities: *OrdererCaps
Channel: &ChannelDefaults
  Policies:
    Readers: {Type: ImplicitMeta, Rule: "ANY Readers"}
    Writers: {Type: ImplicitMeta, Rule: "ANY Writers"}
    Admins: {Type: ImplicitMeta, Rule: "MAJORITY Admins"}
  Capabilities: *ChannelCaps
Profiles:
  BankChannel:
    <<: *ChannelDefaults
    Orderer:
      <<: *OrdererDefaults
      Organizations: [*Orderer]
    Application:
      <<: *AppDefaults
      Organizations: [*Org1, *Org2, *Org3]
YAML
FABRIC_CFG_PATH="$RUNTIME" configtxgen -profile BankChannel -channelID "$CHANNEL" -outputBlock "artifacts/$CHANNEL.block"
echo "crypto + $CHANNEL.block generated in $RUNTIME"
