#!/usr/bin/env bash
# Usage: start-peer.sh <1|2|3>   Starts peer0.org<N> in the foreground (with the ccaas external builder).
set -euo pipefail
. "$(dirname "$0")/network.env"
n=${1:?org number 1-3}
D="$(ORG_MSP_DIR "$n")/peers/$(PEER_HOSTNAME "$n")"; P="$RUNTIME/peer$n"; mkdir -p "$P/data" "$P/cfg"
# per-peer copy of core.yaml: the stock ccaas_builder entry is pointed at our scripts in ./ccaas_builder
sed "s#path: /opt/hyperledger/ccaas_builder#path: $NATIVE_DIR/ccaas_builder#" "$FABRIC_BIN/config/core.yaml" > "$P/cfg/core.yaml"
grep -q "$NATIVE_DIR/ccaas_builder" "$P/cfg/core.yaml" || { echo "externalBuilders patch failed"; exit 1; }
export FABRIC_CFG_PATH="$P/cfg"
export CORE_PEER_ID="$(PEER_HOSTNAME "$n")" CORE_PEER_LOCALMSPID="Org${n}MSP" CORE_PEER_MSPCONFIGPATH="$D/msp"
export CORE_PEER_ADDRESS="${PEER_IP[$n]}:${PEER_PORT[$n]}" CORE_PEER_LISTENADDRESS="0.0.0.0:${PEER_PORT[$n]}"
export CORE_PEER_CHAINCODELISTENADDRESS="0.0.0.0:${PEER_CCLISTEN[$n]}"
export CORE_PEER_FILESYSTEMPATH="$P/data"
export CORE_PEER_TLS_ENABLED=true CORE_PEER_TLS_CERT_FILE="$D/tls/server.crt" CORE_PEER_TLS_KEY_FILE="$D/tls/server.key" CORE_PEER_TLS_ROOTCERT_FILE="$D/tls/ca.crt"
# gossip: advertise own address, bootstrap from the other peers (anchor peers also come from the channel config)
export CORE_PEER_GOSSIP_EXTERNALENDPOINT="${PEER_IP[$n]}:${PEER_PORT[$n]}" CORE_PEER_GOSSIP_ENDPOINT="${PEER_IP[$n]}:${PEER_PORT[$n]}"
boot=""; for m in 1 2 3; do [ "$m" != "$n" ] && boot="$boot ${PEER_IP[$m]}:${PEER_PORT[$m]}"; done
export CORE_PEER_GOSSIP_BOOTSTRAP="${boot# }"
export CORE_PEER_GOSSIP_USELEADERELECTION=true CORE_PEER_GOSSIP_ORGLEADER=false
export CORE_OPERATIONS_LISTENADDRESS="127.0.0.1:${PEER_OPS[$n]}"
exec peer node start
