#!/usr/bin/env bash
# All-in-one on this host: crypto -> orderer -> 3 peers -> channel -> chaincode servers/deploy -> wallet.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"; . "$HERE/network.env"
L="$RUNTIME/logs"; mkdir -p "$L"; : > "$RUNTIME/pids"
bg() { name=$1; shift; "$@" > "$L/$name.log" 2>&1 & echo "$! $name" >> "$RUNTIME/pids"; }
[ -d "$CHAINCODE_DIR/node_modules" ] || (cd "$CHAINCODE_DIR" && npm install --omit=dev --no-audit --no-fund)
"$HERE/generate-crypto.sh"
bg orderer "$HERE/start-orderer.sh"; sleep 3
for n in 1 2 3; do bg peer$n "$HERE/start-peer.sh" $n; done; sleep 4
"$HERE/create-channel.sh" all
sleep 2
"$HERE/deploy-chaincode.sh"
for n in 1 2 3; do bg cc$n "$HERE/start-chaincode.sh" $n; done
"$HERE/make-wallet.sh"
echo "network is up. logs: $L   wallet: $RUNTIME/wallet"
