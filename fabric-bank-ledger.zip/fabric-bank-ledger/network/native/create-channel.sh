#!/usr/bin/env bash
# Joins the orderer to the channel (osnadmin, channel participation API) and then every reachable peer.
# Usage: create-channel.sh [orderer|peers|all]   (default all; on GNS3 run "orderer" on block_fixed, "peers" where the CLI can reach them)
set -euo pipefail
. "$(dirname "$0")/network.env"
what=${1:-all}; BLOCK="$RUNTIME/artifacts/$CHANNEL.block"
if [ "$what" = orderer ] || [ "$what" = all ]; then
  osnadmin channel join --channelID "$CHANNEL" --config-block "$BLOCK" -o "$ORDERER_IP:$ORDERER_ADMIN_PORT" \
    --ca-file "$ORDERER_CA" --client-cert "$ORDERER_DIR/tls/server.crt" --client-key "$ORDERER_DIR/tls/server.key"
fi
if [ "$what" = peers ] || [ "$what" = all ]; then
  for n in 1 2 3; do
    ( peer_cli_env "$n"; peer channel join -b "$BLOCK" )
  done
fi
