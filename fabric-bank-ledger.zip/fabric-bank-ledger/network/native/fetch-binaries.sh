#!/usr/bin/env bash
# Downloads Fabric binaries (peer, orderer, configtxgen, cryptogen, osnadmin) + config/ into $FABRIC_BIN.
set -euo pipefail
VER=${FABRIC_VERSION:-2.5.10}
FABRIC_BIN=${FABRIC_BIN:-$HOME/fabric-bin}
mkdir -p "$FABRIC_BIN"
curl -fsSL -o "$FABRIC_BIN/fabric.tgz" "https://github.com/hyperledger/fabric/releases/download/v$VER/hyperledger-fabric-linux-amd64-$VER.tar.gz"
tar -xzf "$FABRIC_BIN/fabric.tgz" -C "$FABRIC_BIN"   # creates bin/ and config/
rm "$FABRIC_BIN/fabric.tgz"
ls "$FABRIC_BIN/bin"
