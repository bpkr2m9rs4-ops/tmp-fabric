#!/usr/bin/env bash
# Stops everything started by up-local.sh. Add CLEAN=1 to also delete all generated state.
HERE="$(cd "$(dirname "$0")" && pwd)"; . "$HERE/network.env"
if [ -f "$RUNTIME/pids" ]; then
  while read -r pid name; do pkill -P "$pid" 2>/dev/null; kill "$pid" 2>/dev/null; done < "$RUNTIME/pids"
fi
pkill -f "fabric-chaincode-node server" 2>/dev/null; pkill -x orderer 2>/dev/null; pkill -x peer 2>/dev/null
sleep 1; : > "$RUNTIME/pids" 2>/dev/null
[ "${CLEAN:-0}" = 1 ] && rm -rf "$RUNTIME"
echo down
