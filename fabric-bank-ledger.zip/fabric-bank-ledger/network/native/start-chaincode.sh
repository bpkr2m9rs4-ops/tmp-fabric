#!/usr/bin/env bash
# Usage: start-chaincode.sh <1|2|3>  Runs the Node chaincode as an external server for peer N (foreground).
# Needs: node >= 18 and `npm install` done in $CHAINCODE_DIR (copy that dir to the peer node on GNS3).
set -euo pipefail
. "$(dirname "$0")/network.env"
n=${1:?org number}
cd "$CHAINCODE_DIR"
export CHAINCODE_SERVER_ADDRESS="0.0.0.0:${CC_PORT[$n]}"
export CHAINCODE_ID="$(cat "$RUNTIME/cc/pkgid.$n")"
exec npm run start:server
