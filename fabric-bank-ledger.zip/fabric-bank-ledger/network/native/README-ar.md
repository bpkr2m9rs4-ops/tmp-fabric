# تشغيل شبكة Fabric (بدون Docker)

الحالة: **وضع local** (كل المكونات على جهاز واحد) جُرّب فعليًا، ونجح اختبار `app/test/e2e-fabric.js` عليه.
**وضع gns3** (عقد منفصلة بعناوينها) يستخدم نفس السكربتات بعناوين مختلفة لكنه لم يُجرَّب بعد على GNS3.

## أ) تجربة سريعة على جهاز واحد (Linux/WSL/Ubuntu)
```bash
cd network/native
chmod +x *.sh ccaas_builder/bin/*
./fetch-binaries.sh          # ينزّل peer/orderer/cryptogen/configtxgen/osnadmin إلى ~/fabric-bin
./up-local.sh                # شهادات + orderer + 3 أقران + قناة bankchannel + chaincode + محفظة
cd ../../app && npm install
E2E_FABRIC=1 node --test --disable-warning=ExperimentalWarning test/e2e-fabric.js   # المتوقع: pass 1
cd ../network/native && ./down.sh      # إيقاف (CLEAN=1 ./down.sh يمسح كل شيء)
```
المتطلبات: bash وcurl وNode 22 وnpm. السجلات في `~/fabric-run/logs`.

## ب) على عقد GNS3 (MODE=gns3)
يلزم أن تكون العقد Debian/Ubuntu (وليس Alpine) وفيها bash وcurl وNode 22، ومتصلة ببعضها.

| العقدة | العنوان | يعمل عليها |
|---|---|---|
| block_fixed | 192.168.10.11 | orderer، وأوامر الإدارة (القناة والـ chaincode) |
| block-peer-1/2/3 | .12 / .13 / .14 | peer + chaincode server الخاص به |
| Core-Banking-App | 192.168.30.10 | التطبيق |

1. على **كل** عقدة بلوكتشين: انسخ مجلد المشروع، ثم `export MODE=gns3` و`./fetch-binaries.sh`.
2. على block_fixed فقط: `MODE=gns3 ./generate-crypto.sh` ثم انسخ المجلد `~/fabric-run/crypto` و`~/fabric-run/artifacts` إلى نفس المسار على بقية العقد.
3. على block_fixed: `MODE=gns3 ./start-orderer.sh`.
4. على كل peer رقم N: `MODE=gns3 ./start-peer.sh N`.
5. على block_fixed: `MODE=gns3 ./create-channel.sh all` ثم `MODE=gns3 ./deploy-chaincode.sh` (يتصل بالأقران عن بعد).
6. انسخ `~/fabric-run/cc/pkgid.N` من block_fixed إلى peer N، وشغّل هناك: `cd chaincode/bank-ledger && npm install --omit=dev` ثم `MODE=gns3 ./start-chaincode.sh N` (من مجلد network/native).
7. على block_fixed: `MODE=gns3 ./make-wallet.sh` وانسخ مجلد `wallet` إلى Core-Banking-App.
8. على Core-Banking-App شغّل التطبيق بالوضع الحقيقي (انظر docs/README-ar.md، القسم 4).

لا بد قبل ذلك من فتح المنافذ في سياسة Ryu (7050 و7051 و7052 و8051 بين العقد) بموافقتك.
