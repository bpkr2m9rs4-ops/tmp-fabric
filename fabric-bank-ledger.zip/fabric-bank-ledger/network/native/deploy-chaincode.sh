#!/usr/bin/env bash
# Chaincode lifecycle for chaincode-as-a-service. For each org: package (connection.json points to THAT peer's
# chaincode server), install, approve; then commit with the 2-of-3 endorsement policy.
# Writes package ids to $RUNTIME/cc/pkgid.<n> (start-chaincode.sh reads them).
set -euo pipefail
. "$(dirname "$0")/network.env"
mkdir -p "$RUNTIME/cc"; cd "$RUNTIME/cc"
ORD=(-o "$ORDERER_IP:$ORDERER_PORT" --ordererTLSHostnameOverride "$ORDERER_HOSTNAME" --tls --cafile "$ORDERER_CA")
for n in 1 2 3; do
  # The chaincode server runs on the same node as its peer; peers reach it on CC_HOST:CC_PORT.
  host=${CC_HOST_OVERRIDE:-${PEER_IP[$n]}}
  printf '{"address":"%s:%s","dial_timeout":"10s","tls_required":false}\n' "$host" "${CC_PORT[$n]}" > connection.json
  printf '{"type":"ccaas","label":"%s_%s"}\n' "$CC_NAME" "$CC_VERSION" > metadata.json
  tar -czf code.tar.gz connection.json && tar -czf "pkg$n.tgz" metadata.json code.tar.gz
  ( peer_cli_env "$n"
    peer lifecycle chaincode install "pkg$n.tgz"
    id=$(peer lifecycle chaincode calculatepackageid "pkg$n.tgz"); echo "$id" > "pkgid.$n"
    peer lifecycle chaincode approveformyorg "${ORD[@]}" --channelID "$CHANNEL" --name "$CC_NAME" --version "$CC_VERSION" \
      --package-id "$id" --sequence "$CC_SEQUENCE" --signature-policy "$CC_POLICY" )
done
( peer_cli_env 1
  args=(); for n in 1 2 3; do args+=(--peerAddresses "${PEER_IP[$n]}:${PEER_PORT[$n]}" --tlsRootCertFiles "$(ORG_MSP_DIR $n)/peers/$(PEER_HOSTNAME $n)/tls/ca.crt"); done
  peer lifecycle chaincode checkcommitreadiness --channelID "$CHANNEL" --name "$CC_NAME" --version "$CC_VERSION" --sequence "$CC_SEQUENCE" --signature-policy "$CC_POLICY"
  peer lifecycle chaincode commit "${ORD[@]}" --channelID "$CHANNEL" --name "$CC_NAME" --version "$CC_VERSION" --sequence "$CC_SEQUENCE" --signature-policy "$CC_POLICY" "${args[@]}"
  peer lifecycle chaincode querycommitted --channelID "$CHANNEL" --name "$CC_NAME" )
