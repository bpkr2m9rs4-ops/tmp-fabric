#!/usr/bin/env bash
# Builds the app wallet from the cryptogen users: <wallet>/<label>/{cert.pem,key.pem,mspid} + peer-tls-ca.pem
# Usage: make-wallet.sh [wallet_dir]   (default $RUNTIME/wallet). Copy the result to Core-Banking-App:/opt/bank/wallet.
set -euo pipefail
. "$(dirname "$0")/network.env"
W=${1:-$RUNTIME/wallet}; rm -rf "$W"; mkdir -p "$W"
mk() { # label org user
  local d; d="$(ORG_MSP_DIR "$2")/users/$3@$(ORG_DOMAIN "$2")/msp"
  mkdir -p "$W/$1"; cp "$d"/signcerts/*.pem "$W/$1/cert.pem"; cp "$d"/keystore/* "$W/$1/key.pem"; printf 'Org%sMSP' "$2" > "$W/$1/mspid"
}
mk admin1 1 User1; mk teller1 1 User2; mk teller2 1 User3
mk approver1 2 User1; mk approver2 2 User2; mk senior1 2 User3
mk auditor1 3 User1
cp "$(ORG_MSP_DIR 1)/peers/$(PEER_HOSTNAME 1)/tls/ca.crt" "$W/peer-tls-ca.pem"
echo "wallet at $W"; ls "$W"
