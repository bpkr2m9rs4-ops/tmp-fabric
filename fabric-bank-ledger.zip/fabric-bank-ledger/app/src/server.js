'use strict';
const express = require('express');
const path = require('path');
const fs = require('fs');
const cfg = require('./config');
const dbm = require('./db');
const { BankService } = require('./service');
const { Siem } = require('./siem');
const { AppError } = require('./errors');
const { verifyPassword, signToken, verifyToken } = require('./auth');
const { runIntegrityCheck } = require('./integrity');

function createApp({ db, ledger, siem, secret = cfg.tokenSecret }) {
  const svc = new BankService({ db, ledger, siem });
  const app = express();
  app.use(express.json({ limit: '100kb' }));
  app.use(express.static(path.join(__dirname, '../public')));

  const loginFails = new Map();
  const wrap = (fn) => (req, res) => Promise.resolve(fn(req, res)).then((r) => res.json(r)).catch((e) => {
    const err = AppError.from(e);
    res.status(err.status).json({ error: err.code, message: err.message.replace(/^E_[A-Z_]+: /, '') });
  });
  const auth = (req, _res, next) => {
    try {
      const p = verifyToken((req.headers.authorization || '').replace(/^Bearer /, ''), secret);
      const u = db.prepare('SELECT * FROM users WHERE username=?').get(p.u);
      if (!u || !u.active) throw new AppError('E_UNAUTHENTICATED', 'unknown or disabled user');
      req.user = u; next();
    } catch (e) { const err = AppError.from(e); _res.status(err.status).json({ error: err.code, message: err.message }); }
  };

  app.post('/api/login', wrap(async (req) => {
    const { username, password } = req.body || {};
    const key = String(username);
    const f = loginFails.get(key) || { n: 0, until: 0 };
    if (f.until > Date.now()) throw new AppError('E_UNAUTHENTICATED', 'too many failed attempts, try later', 429);
    const u = db.prepare('SELECT * FROM users WHERE username=?').get(key);
    if (!u || !u.active || !verifyPassword(String(password || ''), u.pw_salt, u.pw_hash)) {
      f.n += 1; if (f.n >= 5) { f.until = Date.now() + 60000; f.n = 0; }
      loginFails.set(key, f);
      if (siem) siem.send('WARNING', 'LOGIN_FAILED', { username: key });
      throw new AppError('E_UNAUTHENTICATED', 'invalid credentials');
    }
    loginFails.delete(key);
    return { token: signToken({ u: u.username }, secret, cfg.tokenTtlSec), user: { username: u.username, employeeId: u.employee_id, fullName: u.full_name, role: u.role, mspId: u.msp_id } };
  }));

  app.use('/api', auth);
  app.get('/api/me', wrap(async (req) => svc._eval(req.user, 'GetMyProfile')));
  app.get('/api/accounts', wrap(async () => svc.listAccounts()));
  app.get('/api/transactions', wrap(async (req) => svc.listTransactions(req.user)));
  app.post('/api/transactions', wrap(async (req) => svc.createTransaction(req.user, req.body || {})));
  app.get('/api/transactions/:id', wrap(async (req) => svc.getTransaction(req.user, req.params.id)));
  app.post('/api/transactions/:id/approve', wrap(async (req) => svc.approveTransaction(req.user, req.params.id, (req.body || {}).comment)));
  app.post('/api/transactions/:id/reject', wrap(async (req) => svc.rejectTransaction(req.user, req.params.id, (req.body || {}).reason)));
  app.post('/api/transactions/:id/execute', wrap(async (req) => svc.executeTransaction(req.user, req.params.id)));
  app.post('/api/transactions/:id/corrections', wrap(async (req) => svc.requestCorrection(req.user, req.params.id, req.body || {})));
  app.get('/api/corrections', wrap(async (req) => svc.listCorrections(req.user)));
  app.post('/api/corrections/:id/approve', wrap(async (req) => svc.approveCorrection(req.user, req.params.id, (req.body || {}).comment)));
  app.post('/api/corrections/:id/reject', wrap(async (req) => svc.rejectCorrection(req.user, req.params.id, (req.body || {}).reason)));
  app.post('/api/corrections/:id/execute', wrap(async (req) => svc.executeCorrection(req.user, req.params.id)));
  app.get('/api/employees', wrap(async (req) => svc.listEmployees(req.user)));
  app.post('/api/employees', wrap(async (req) => svc.registerEmployee(req.user, req.body || {})));
  app.post('/api/employees/:id/active', wrap(async (req) => svc.setEmployeeActive(req.user, req.params.id, !!req.body.active, req.body.reason)));
  app.post('/api/reconcile', wrap(async (req) => svc.reconcileExecuting(req.user)));
  app.post('/api/integrity/run', wrap(async (req) => {
    if (!['AUDITOR', 'ADMIN'].includes(req.user.role)) throw new AppError('E_NOT_AUTHORIZED', 'only AUDITOR/ADMIN may run the integrity check');
    return runIntegrityCheck({ db, ledger, label: req.user.fabric_label, siem, ranBy: req.user.employee_id });
  }));
  app.get('/api/integrity/last', wrap(async () => {
    const r = db.prepare('SELECT report FROM integrity_runs ORDER BY id DESC LIMIT 1').get();
    return r ? JSON.parse(r.report) : null;
  }));
  app.get('/api/audit', wrap(async (req) => {
    if (!['AUDITOR', 'ADMIN'].includes(req.user.role)) throw new AppError('E_NOT_AUTHORIZED', 'restricted');
    return db.prepare('SELECT * FROM app_audit ORDER BY id DESC LIMIT 200').all();
  }));
  app.use('/api', (_req, res) => res.status(404).json({ error: 'E_NOT_FOUND', message: 'no such endpoint' }));
  return { app, svc };
}

function buildLedger() {
  if (cfg.ledgerMode === 'fabric') { const { FabricLedgerAdapter } = require('./ledger/fabric'); return new FabricLedgerAdapter(cfg.fabric); }
  const { MockLedgerAdapter } = require('./ledger/mock'); return new MockLedgerAdapter();
}

if (require.main === module) {
  fs.mkdirSync(path.dirname(cfg.dbFile), { recursive: true });
  const db = dbm.open(cfg.dbFile);
  const siem = new Siem(cfg.siem);
  const ledger = buildLedger();
  if (cfg.ledgerMode === 'mock') console.warn('[WARN] LEDGER_MODE=mock: in-memory ledger, data is NOT persistent. Use LEDGER_MODE=fabric for the real network.');
  const { app, svc } = createApp({ db, ledger, siem });
  const go = () => app.listen(cfg.port, cfg.host, () => console.log(`bank-ledger API on http://${cfg.host}:${cfg.port} (ledger=${cfg.ledgerMode})`));
  if (cfg.ledgerMode === 'mock') require('./seed').seedDemo(svc).then(() => { console.log('demo data seeded: users admin1/teller1/teller2/approver1/approver2/senior1/auditor1, password Demo@12345'); go(); });
  else go();
}
module.exports = { createApp, buildLedger };
