'use strict';
// Pure functions: which balance movements does a transaction / correction cause?
function base(type, from, to, amount) {
  if (type === 'DEPOSIT') return [{ account: to, delta: amount }];
  if (type === 'WITHDRAW') return [{ account: from, delta: -amount }];
  if (type === 'TRANSFER') return [{ account: from, delta: -amount }, { account: to, delta: amount }];
  throw new Error(`unknown type ${type}`);
}
function merge(...lists) {
  const m = new Map();
  for (const l of lists) for (const p of l) m.set(p.account, (m.get(p.account) || 0) + p.delta);
  return [...m.entries()].filter(([, d]) => d !== 0).map(([account, delta]) => ({ account, delta }));
}
const negate = (l) => l.map((p) => ({ account: p.account, delta: -p.delta }));

const txPostings = (d) => merge(base(d.txType, d.fromAccount, d.toAccount, Number(d.amountMinor)));

/**
 * Effective amount of a transaction after the given (already executed) corrections.
 * Returns the amount currently "in force" (0 when fully reversed).
 */
function effectiveAmount(d, executedCorrections) {
  let eff = Number(d.amountMinor);
  for (const c of executedCorrections) eff = c.correctionType === 'REVERSAL' ? 0 : Number(c.correctedAmountMinor);
  return eff;
}

/** Postings of one correction given the corrections that were executed before it. */
function correctionPostings(d, priorExecuted, corr) {
  const eff = effectiveAmount(d, priorExecuted);
  const cur = base(d.txType, d.fromAccount, d.toAccount, eff);
  if (corr.correctionType === 'REVERSAL') return merge(negate(cur));
  const next = base(d.txType, d.fromAccount, d.toAccount, Number(corr.correctedAmountMinor));
  return merge(next, negate(cur));
}

module.exports = { txPostings, correctionPostings, effectiveAmount, merge };
