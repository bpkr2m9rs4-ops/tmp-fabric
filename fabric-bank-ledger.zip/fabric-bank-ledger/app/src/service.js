'use strict';
const { tx: sqlTx } = require('./db');
const { AppError } = require('./errors');
const { sha256, canonicalize, detailsHash, postingsHash, randomSalt, newId } = require('./hash');
const { txPostings, correctionPostings } = require('./postings');
const { hashPassword } = require('./auth');

const TX_TYPES = ['DEPOSIT', 'WITHDRAW', 'TRANSFER'];
const ROLE_MSP = { ADMIN: 'Org1MSP', TELLER: 'Org1MSP', APPROVER: 'Org2MSP', SENIOR_APPROVER: 'Org2MSP', AUDITOR: 'Org3MSP' };
const now = () => new Date().toISOString();

/** Hash that binds the DB-side content of a correction to the ledger record. */
function correctionHash(c) {
  return sha256(canonicalize({
    corrId: c.corrId, originalTxId: c.originalTxId, correctionType: c.correctionType, reason: c.reason,
    correctedAmountMinor: c.correctedAmountMinor === undefined ? null : c.correctedAmountMinor,
    correctedNarrative: c.correctedNarrative || null, salt: c.salt,
  }));
}

class BankService {
  constructor({ db, ledger, siem }) {
    this.db = db; this.ledger = ledger; this.siem = siem;
  }

  // -------------------------------------------------------------- utilities
  _audit(user, action, refId, detail) {
    this.db.prepare('INSERT INTO app_audit(at,username,action,ref_id,detail) VALUES(?,?,?,?,?)')
      .run(now(), user ? user.username : null, action, refId || null, detail ? JSON.stringify(detail) : null);
  }
  _mirror(refId, kind, status) {
    this.db.prepare(`INSERT INTO status_mirror(ref_id,ref_kind,status,updated_at) VALUES(?,?,?,?)
      ON CONFLICT(ref_id) DO UPDATE SET status=excluded.status, updated_at=excluded.updated_at`).run(refId, kind, status, now());
  }
  async _submit(user, fn, ...args) {
    try { return JSON.parse(await this.ledger.submit(user.fabric_label, fn, ...args)); } catch (e) { throw AppError.from(e); }
  }
  async _eval(user, fn, ...args) {
    try { return JSON.parse(await this.ledger.evaluate(user.fabric_label, fn, ...args)); } catch (e) { throw AppError.from(e); }
  }
  _details(txId) {
    const r = this.db.prepare('SELECT * FROM tx_details WHERE tx_id=?').get(txId);
    if (!r) return null;
    return { txId: r.tx_id, txType: r.tx_type, fromAccount: r.from_account, toAccount: r.to_account, amountMinor: r.amount_minor,
      currency: r.currency, narrative: r.narrative, salt: r.salt, dataHash: r.data_hash, createdBy: r.created_by, createdAt: r.created_at };
  }
  _corrRow(corrId) {
    const r = this.db.prepare('SELECT * FROM corrections WHERE corr_id=?').get(corrId);
    if (!r) return null;
    return { corrId: r.corr_id, originalTxId: r.original_tx_id, correctionType: r.correction_type, reason: r.reason,
      correctedAmountMinor: r.corrected_amount_minor, correctedNarrative: r.corrected_narrative, salt: r.corrected_salt,
      correctedHash: r.corrected_hash, requestedBy: r.requested_by, requestedAt: r.requested_at };
  }
  _alert(sev, event, fields) { if (this.siem) this.siem.send(sev, event, fields); }

  // ----------------------------------------------------------- employees
  /** One-time: first ADMIN (also creates the login). */
  async bootstrap({ username, password, employeeId, fullName }) {
    this.ledger.ensureIdentity && this.ledger.ensureIdentity(username, ROLE_MSP.ADMIN);
    const u = { username, fabric_label: username };
    await this._submit(u, 'Bootstrap', employeeId, fullName);
    this._insertUser({ username, password, employeeId, fullName, role: 'ADMIN', mspId: ROLE_MSP.ADMIN });
  }

  _insertUser({ username, password, employeeId, fullName, role, mspId }) {
    const { salt, hash } = hashPassword(password);
    this.db.prepare('INSERT INTO users(username,employee_id,full_name,role,msp_id,fabric_label,pw_salt,pw_hash) VALUES(?,?,?,?,?,?,?,?)')
      .run(username, employeeId, fullName, role, mspId, username, salt, hash);
  }

  async registerEmployee(admin, { username, password, employeeId, fullName, role, approvalLimitMinor }) {
    if (!ROLE_MSP[role]) throw new AppError('E_VALIDATION', `unknown role ${role}`);
    if (!password || password.length < 8) throw new AppError('E_VALIDATION', 'password must be at least 8 characters');
    const mspId = ROLE_MSP[role];
    this.ledger.ensureIdentity && this.ledger.ensureIdentity(username, mspId);
    let who;
    try { who = JSON.parse(await this.ledger.evaluate(username, 'WhoAmI')); } catch (e) { throw AppError.from(e); }
    await this._submit(admin, 'RegisterEmployee', employeeId, fullName, role, approvalLimitMinor == null ? '' : String(approvalLimitMinor), who.identityId, who.mspId);
    this._insertUser({ username, password, employeeId, fullName, role, mspId });
    this._audit(admin, 'EMPLOYEE_REGISTERED', employeeId, { role });
    return { employeeId, role };
  }

  async setEmployeeActive(admin, employeeId, active, reason) {
    const r = await this._submit(admin, 'SetEmployeeActive', employeeId, String(!!active), reason);
    this.db.prepare('UPDATE users SET active=? WHERE employee_id=?').run(active ? 1 : 0, employeeId);
    this._audit(admin, active ? 'EMPLOYEE_ACTIVATED' : 'EMPLOYEE_DEACTIVATED', employeeId, { reason });
    return r;
  }

  listEmployees(user) { return this._eval(user, 'ListEmployees'); }

  // ------------------------------------------------------------ accounts
  createAccount({ accountNo, holder, currency, openingMinor }) {
    this.db.prepare('INSERT INTO accounts(account_no,holder,currency,opening_minor,balance_minor) VALUES(?,?,?,?,?)')
      .run(accountNo, holder, currency, openingMinor, openingMinor);
  }
  listAccounts() { return this.db.prepare('SELECT account_no accountNo, holder, currency, balance_minor balanceMinor FROM accounts ORDER BY account_no').all(); }

  // -------------------------------------------------------- transactions
  async createTransaction(user, input) {
    const { txType, fromAccount, toAccount, narrative } = input;
    const amountMinor = Number(input.amountMinor);
    if (!TX_TYPES.includes(txType)) throw new AppError('E_VALIDATION', `txType must be one of ${TX_TYPES.join('/')}`);
    if (!Number.isSafeInteger(amountMinor) || amountMinor <= 0) throw new AppError('E_VALIDATION', 'amountMinor must be a positive integer');
    const acc = (no) => this.db.prepare('SELECT * FROM accounts WHERE account_no=?').get(no);
    if (txType !== 'DEPOSIT' && !acc(fromAccount)) throw new AppError('E_VALIDATION', 'fromAccount not found');
    if (txType !== 'WITHDRAW' && !acc(toAccount)) throw new AppError('E_VALIDATION', 'toAccount not found');
    if (txType === 'TRANSFER' && fromAccount === toAccount) throw new AppError('E_VALIDATION', 'cannot transfer to the same account');
    const currency = (acc(txType === 'DEPOSIT' ? toAccount : fromAccount)).currency;
    if (txType === 'TRANSFER' && acc(toAccount).currency !== currency) throw new AppError('E_VALIDATION', 'currency mismatch between accounts');

    const d = {
      txId: newId('TX'), txType, fromAccount: txType === 'DEPOSIT' ? null : fromAccount, toAccount: txType === 'WITHDRAW' ? null : toAccount,
      amountMinor, currency, narrative: String(narrative || '').slice(0, 200), salt: randomSalt(),
    };
    d.dataHash = detailsHash(d);
    // 1) ledger first: if the approval workflow cannot be opened, nothing is stored.
    await this._submit(user, 'CreateTransaction', d.txId, txType, d.dataHash, String(amountMinor), currency);
    // 2) details stored off-chain; their fingerprint is already on-chain.
    this.db.prepare(`INSERT INTO tx_details(tx_id,tx_type,from_account,to_account,amount_minor,currency,narrative,salt,data_hash,created_by,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(d.txId, txType, d.fromAccount, d.toAccount, amountMinor, currency, d.narrative, d.salt, d.dataHash, user.employee_id, now());
    this._mirror(d.txId, 'TX', 'PENDING_APPROVAL');
    this._audit(user, 'TX_CREATED', d.txId, { txType, amountMinor });
    return { txId: d.txId, status: 'PENDING_APPROVAL', dataHash: d.dataHash };
  }

  async approveTransaction(user, txId, comment) {
    const r = await this._submit(user, 'ApproveTransaction', txId, comment || '');
    this._mirror(txId, 'TX', r.status); this._audit(user, 'TX_APPROVED', txId); return r;
  }
  async rejectTransaction(user, txId, reason) {
    const r = await this._submit(user, 'RejectTransaction', txId, reason || '');
    this._mirror(txId, 'TX', r.status); this._audit(user, 'TX_REJECTED', txId, { reason }); return r;
  }

  /**
   * Executes an APPROVED transaction. Gates (all must pass, in order):
   *  1. ledger status == APPROVED (chaincode refuses StartExecution otherwise)
   *  2. DB details hash == hash recorded on the ledger (tamper gate)
   *  3. ledger lock EXECUTION_STARTED (prevents double execution)
   *  4. balance postings applied atomically in SQL, then fingerprint written back to the ledger.
   */
  async executeTransaction(user, txId) {
    const g = await this._eval(user, 'GetTransaction', txId);
    if (g.status !== 'APPROVED') throw new AppError('E_INVALID_STATE', `transaction ${txId} is ${g.status}; only APPROVED can be executed`);
    const d = this._details(txId);
    if (!d) throw new AppError('E_TAMPER_DETECTED', `details of ${txId} are missing from the database`);
    if (detailsHash(d) !== g.record.dataHash || Number(d.amountMinor) !== Number(g.record.amountMinor)) {
      this._alert('CRITICAL', 'EXECUTION_BLOCKED_TAMPER', { txId });
      throw new AppError('E_TAMPER_DETECTED', `stored details of ${txId} do not match the ledger fingerprint; execution refused`);
    }
    await this._submit(user, 'StartExecution', txId);
    this._mirror(txId, 'TX', 'EXECUTING');
    let hash;
    try {
      hash = this._applyPostings('TX', txId, txPostings(d));
    } catch (e) {
      const err = AppError.from(e);
      await this._submit(user, 'FailExecution', txId, err.message.slice(0, 180));
      this._mirror(txId, 'TX', 'EXECUTION_FAILED'); this._audit(user, 'TX_EXEC_FAILED', txId, { error: err.message });
      throw err;
    }
    await this._submit(user, 'ConfirmExecution', txId, hash);
    this._mirror(txId, 'TX', 'EXECUTED'); this._audit(user, 'TX_EXECUTED', txId, { executionHash: hash });
    return { txId, status: 'EXECUTED', executionHash: hash };
  }

  /** Atomic balance update + append-only postings + execution fingerprint. Returns the execution hash. */
  _applyPostings(kind, refId, postings) {
    return sqlTx(this.db, () => {
      const ts = now();
      for (const p of postings) {
        const a = this.db.prepare('SELECT balance_minor b FROM accounts WHERE account_no=?').get(p.account);
        if (!a) throw new AppError('E_VALIDATION', `account ${p.account} not found`);
        if (a.b + p.delta < 0) throw new AppError('E_INSUFFICIENT_FUNDS', `account ${p.account} has insufficient funds`);
        this.db.prepare('UPDATE accounts SET balance_minor = balance_minor + ? WHERE account_no=?').run(p.delta, p.account);
        this.db.prepare('INSERT INTO postings(ref_id,ref_kind,account_no,delta_minor,posted_at) VALUES(?,?,?,?,?)').run(refId, kind, p.account, p.delta, ts);
      }
      const h = postingsHash(refId, postings);
      this.db.prepare('INSERT INTO executions(ref_id,ref_kind,execution_hash,executed_at) VALUES(?,?,?,?)').run(refId, kind, h, ts);
      return h;
    });
  }

  // ----------------------------------------------------------- corrections
  async requestCorrection(user, txId, { correctionType, reason, correctedAmountMinor, correctedNarrative }) {
    const d = this._details(txId);
    if (!d) throw new AppError('E_NOT_FOUND', `transaction ${txId} not found`);
    if (!['REVERSAL', 'AMEND'].includes(correctionType)) throw new AppError('E_VALIDATION', 'correctionType must be REVERSAL or AMEND');
    const c = {
      corrId: newId('CORR'), originalTxId: txId, correctionType, reason: String(reason || '').trim(),
      correctedAmountMinor: correctionType === 'AMEND' ? Number(correctedAmountMinor) : null,
      correctedNarrative: correctedNarrative || null, salt: randomSalt(),
    };
    c.correctedHash = correctionHash(c);
    await this._submit(user, 'RequestCorrection', c.corrId, txId, correctionType, c.reason, c.correctedHash,
      c.correctedAmountMinor == null ? '' : String(c.correctedAmountMinor));
    this.db.prepare(`INSERT INTO corrections(corr_id,original_tx_id,correction_type,reason,corrected_amount_minor,corrected_narrative,corrected_salt,corrected_hash,requested_by,requested_at)
      VALUES(?,?,?,?,?,?,?,?,?,?)`).run(c.corrId, txId, correctionType, c.reason, c.correctedAmountMinor, c.correctedNarrative, c.salt, c.correctedHash, user.employee_id, now());
    this._mirror(c.corrId, 'CORR', 'REQUESTED'); this._audit(user, 'CORR_REQUESTED', c.corrId, { txId, correctionType });
    return { corrId: c.corrId, originalTxId: txId, status: 'REQUESTED' };
  }

  async approveCorrection(user, corrId, comment) {
    const r = await this._submit(user, 'ApproveCorrection', corrId, comment || '');
    this._mirror(corrId, 'CORR', r.status); this._audit(user, 'CORR_APPROVED', corrId); return r;
  }
  async rejectCorrection(user, corrId, reason) {
    const r = await this._submit(user, 'RejectCorrection', corrId, reason || '');
    this._mirror(corrId, 'CORR', r.status); this._audit(user, 'CORR_REJECTED', corrId, { reason }); return r;
  }

  async executeCorrection(user, corrId) {
    const g = await this._eval(user, 'GetCorrection', corrId);
    if (g.status !== 'APPROVED') throw new AppError('E_INVALID_STATE', `correction ${corrId} is ${g.status}; only APPROVED can be executed`);
    const c = this._corrRow(corrId);
    const d = c && this._details(c.originalTxId);
    if (!c || !d) throw new AppError('E_TAMPER_DETECTED', `database rows of correction ${corrId} are missing`);
    if (correctionHash(c) !== g.record.correctedDataHash || detailsHash(d) !== g.record.originalDataHash) {
      this._alert('CRITICAL', 'CORRECTION_EXECUTION_BLOCKED_TAMPER', { corrId });
      throw new AppError('E_TAMPER_DETECTED', `stored data of ${corrId} does not match the ledger fingerprints; execution refused`);
    }
    const prior = await this._executedCorrections(user, c.originalTxId, corrId);
    await this._submit(user, 'StartCorrectionExecution', corrId);
    this._mirror(corrId, 'CORR', 'EXECUTING');
    let hash;
    try {
      hash = this._applyPostings('CORR', corrId, correctionPostings(d, prior, c));
    } catch (e) {
      const err = AppError.from(e);
      await this._submit(user, 'FailCorrectionExecution', corrId, err.message.slice(0, 180));
      this._mirror(corrId, 'CORR', 'EXECUTION_FAILED'); throw err;
    }
    await this._submit(user, 'ConfirmCorrectionExecution', corrId, hash);
    this._mirror(corrId, 'CORR', 'EXECUTED'); this._audit(user, 'CORR_EXECUTED', corrId, { executionHash: hash });
    return { corrId, status: 'EXECUTED', executionHash: hash };
  }

  /** Corrections of a transaction that were EXECUTED on the ledger (authoritative), oldest first, excluding `exceptId`. */
  async _executedCorrections(user, txId, exceptId) {
    const list = await this._eval(user, 'ListCorrections', txId);
    return list.filter((x) => x.status === 'EXECUTED' && x.record.corrId !== exceptId)
      .sort((a, b) => (a.record.requestedAt < b.record.requestedAt ? -1 : 1))
      .map((x) => this._corrRow(x.record.corrId)).filter(Boolean);
  }

  // --------------------------------------------------------------- queries
  async listTransactions(user) {
    const rows = await this._eval(user, 'ListTransactions');
    return rows.map((r) => {
      const d = this._details(r.record.txId);
      return {
        txId: r.record.txId, txType: r.record.txType, amountMinor: r.record.amountMinor, currency: r.record.currency,
        status: r.status, createdBy: r.record.createdBy.employeeId, createdAt: r.record.createdAt, dataHash: r.record.dataHash,
        fromAccount: d && d.fromAccount, toAccount: d && d.toAccount, narrative: d && d.narrative,
        hashMatches: d ? detailsHash(d) === r.record.dataHash : false, chainIntact: r.chain.intact,
      };
    }).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  }

  async getTransaction(user, txId) {
    const g = await this._eval(user, 'GetTransaction', txId);
    const d = this._details(txId);
    const corrs = await this._eval(user, 'ListCorrections', txId);
    return {
      ledger: g, details: d, hashMatches: d ? detailsHash(d) === g.record.dataHash : false,
      corrections: corrs.map((c) => ({ ...c, details: this._corrRow(c.record.corrId), hashMatches: (() => { const r = this._corrRow(c.record.corrId); return r ? correctionHash(r) === c.record.correctedDataHash : false; })() })),
      postings: this.db.prepare("SELECT ref_id refId, ref_kind refKind, account_no account, delta_minor delta, posted_at postedAt FROM postings WHERE ref_id=? OR ref_id IN (SELECT corr_id FROM corrections WHERE original_tx_id=?) ORDER BY id").all(txId, txId),
    };
  }

  async listCorrections(user) {
    const txs = await this._eval(user, 'ListTransactions');
    const out = [];
    for (const t of txs) {
      for (const c of await this._eval(user, 'ListCorrections', t.record.txId)) {
        out.push({ corrId: c.record.corrId, originalTxId: c.record.originalTxId, correctionType: c.record.correctionType, reason: c.record.reason,
          status: c.status, requestedBy: c.record.requestedBy.employeeId, requestedAt: c.record.requestedAt,
          approvedBy: (c.events.find((e) => e.eventType === 'CORRECTION_APPROVED') || {}).actor?.employeeId || null,
          correctedAmountMinor: c.record.correctedAmountMinor, previousCorrectionId: c.record.previousCorrectionId });
      }
    }
    return out.sort((a, b) => (a.requestedAt < b.requestedAt ? 1 : -1));
  }

  /** Recovery: finishes transactions stuck in EXECUTING (crash between DB commit and ledger confirm). */
  async reconcileExecuting(user) {
    const fixed = [];
    for (const t of await this._eval(user, 'ListTransactions')) {
      if (t.status !== 'EXECUTING') continue;
      const ex = this.db.prepare('SELECT execution_hash h FROM executions WHERE ref_id=?').get(t.record.txId);
      if (ex) { await this._submit(user, 'ConfirmExecution', t.record.txId, ex.h); this._mirror(t.record.txId, 'TX', 'EXECUTED'); fixed.push({ id: t.record.txId, action: 'CONFIRMED' }); }
      else { await this._submit(user, 'FailExecution', t.record.txId, 'recovered: no postings were applied'); this._mirror(t.record.txId, 'TX', 'EXECUTION_FAILED'); fixed.push({ id: t.record.txId, action: 'FAILED' }); }
    }
    return fixed;
  }
}

module.exports = { BankService, correctionHash, ROLE_MSP };
