'use strict';
// Tamper-detection engine. Re-derives everything it can from independent sources and compares:
//   ledger event chains  <->  ledger write-once history  <->  database details/postings/balances.
// It never trusts a verdict computed by the component being checked (hash chains are recomputed here).
const { canonicalize, sha256, detailsHash, postingsHash } = require('./hash');
const { txPostings, correctionPostings } = require('./postings');
const { correctionHash } = require('./service');

const GENESIS = '0'.repeat(64);
const eventHash = (e) => { const { eventHash: _h, ...rest } = e; return sha256(canonicalize(rest)); };

function checkChain(events) {
  let prev = GENESIS;
  for (let i = 0; i < events.length; i++) {
    const e = events[i];
    if (e.seq !== i + 1) return `sequence gap at position ${i + 1}`;
    if (e.prevHash !== prev) return `prevHash mismatch at seq ${e.seq}`;
    if (eventHash(e) !== e.eventHash) return `eventHash mismatch at seq ${e.seq}`;
    prev = e.eventHash;
  }
  return null;
}

async function runIntegrityCheck({ db, ledger, label, siem, ranBy }) {
  const findings = [];
  const add = (severity, code, ref, message) => findings.push({ severity, code, ref, message });
  const ev = async (fn, ...a) => JSON.parse(await ledger.evaluate(label, fn, ...a));
  const stats = { transactions: 0, corrections: 0, ledgerEventsChecked: 0, historyKeysChecked: 0, accounts: 0 };

  const ledgerTxs = await ev('ListTransactions');
  const dbTx = new Map(db.prepare('SELECT * FROM tx_details').all().map((r) => [r.tx_id, r]));
  const mirror = new Map(db.prepare('SELECT * FROM status_mirror').all().map((r) => [r.ref_id, r]));
  const execs = new Map(db.prepare('SELECT * FROM executions').all().map((r) => [r.ref_id, r]));
  const postingsBy = new Map();
  for (const p of db.prepare('SELECT * FROM postings ORDER BY id').all()) {
    if (!postingsBy.has(p.ref_id)) postingsBy.set(p.ref_id, []);
    postingsBy.get(p.ref_id).push({ account: p.account_no, delta: p.delta_minor });
  }
  const dbCorr = new Map(db.prepare('SELECT * FROM corrections').all().map((r) => [r.corr_id, r]));
  const seenCorr = new Set();
  const sameP = (a, b) => canonicalize([...a].sort((x, y) => (x.account < y.account ? -1 : 1))) === canonicalize([...b].sort((x, y) => (x.account < y.account ? -1 : 1)));
  const historyOk = async (key) => {
    stats.historyKeysChecked++;
    const h = await ev('GetRecordHistory', key);
    if (h.writes !== 1 || h.history.some((x) => x.isDelete)) add('CRITICAL', 'LEDGER_RECORD_REWRITTEN', key, `key written ${h.writes} times / deleted: record must be write-once`);
  };

  // ---- ledger-side checks + DB cross-checks per transaction
  for (const lt of ledgerTxs) {
    stats.transactions++;
    const id = lt.record.txId;
    const full = await ev('GetTransaction', id);
    stats.ledgerEventsChecked += full.events.length;
    const chainErr = checkChain(full.events);
    if (chainErr) add('CRITICAL', 'LEDGER_CHAIN_BROKEN', id, `event chain broken: ${chainErr}`);
    await historyOk(`TX:${id}`);
    for (const e of full.events) await historyOk(`EVT:${id}:${String(e.seq).padStart(4, '0')}`);

    const row = dbTx.get(id);
    if (!row) { add('CRITICAL', 'DB_ROW_MISSING', id, 'transaction exists on ledger but its details are missing in the database (deleted?)'); continue; }
    const d = { txId: row.tx_id, txType: row.tx_type, fromAccount: row.from_account, toAccount: row.to_account, amountMinor: row.amount_minor, currency: row.currency, narrative: row.narrative, salt: row.salt };
    if (detailsHash(d) !== full.record.dataHash) add('CRITICAL', 'DETAILS_TAMPERED', id, 'database details no longer match the hash anchored on the ledger');
    if (Number(row.amount_minor) !== Number(full.record.amountMinor) || row.currency !== full.record.currency || row.tx_type !== full.record.txType) add('CRITICAL', 'AMOUNT_MISMATCH', id, 'amount/currency/type differ between database and ledger');
    if (row.data_hash !== full.record.dataHash) add('WARNING', 'STORED_HASH_DIFFERS', id, 'data_hash column differs from ledger hash');
    const m = mirror.get(id);
    if (!m || m.status !== full.status) add('WARNING', 'STATUS_MIRROR_STALE', id, `db mirror '${m ? m.status : 'none'}' vs ledger '${full.status}'`);
    if (full.status === 'EXECUTING') add('WARNING', 'STUCK_EXECUTING', id, 'transaction is EXECUTING; run reconcile');

    // execution evidence
    const execEvt = full.events.find((e) => e.eventType === 'EXECUTED');
    const ex = execs.get(id);
    const p = postingsBy.get(id) || [];
    if (full.status === 'EXECUTED') {
      if (!ex) add('CRITICAL', 'EXECUTION_RECORD_MISSING', id, 'ledger says EXECUTED but no execution record in database');
      else {
        if (ex.execution_hash !== execEvt.extra.executionHash) add('CRITICAL', 'EXECUTION_HASH_MISMATCH', id, 'execution hash in database differs from ledger');
        if (postingsHash(id, p) !== execEvt.extra.executionHash) add('CRITICAL', 'POSTINGS_TAMPERED', id, 'balance postings no longer match the execution hash anchored on the ledger');
      }
      if (!sameP(p, txPostings(d))) add('CRITICAL', 'POSTINGS_UNEXPECTED', id, 'postings differ from the movements implied by the approved details');
    } else if (p.length) {
      add('CRITICAL', 'UNAUTHORISED_EXECUTION', id, `funds moved for a transaction whose ledger status is ${full.status} (no approval/execution on ledger)`);
    }

    // corrections of this transaction
    const corrs = await ev('ListCorrections', id);
    const executedPrior = [];
    for (const c of corrs.sort((a, b) => (a.record.requestedAt < b.record.requestedAt ? -1 : 1))) {
      stats.corrections++; seenCorr.add(c.record.corrId);
      const cid = c.record.corrId;
      stats.ledgerEventsChecked += c.events.length;
      const cErr = checkChain(c.events);
      if (cErr) add('CRITICAL', 'LEDGER_CHAIN_BROKEN', cid, `correction event chain broken: ${cErr}`);
      await historyOk(`CORR:${cid}`);
      for (const e of c.events) await historyOk(`CEVT:${cid}:${String(e.seq).padStart(4, '0')}`);
      if (c.record.originalDataHash !== full.record.dataHash) add('CRITICAL', 'CORRECTION_LINK_BROKEN', cid, 'correction does not reference the original transaction hash');
      const cr = dbCorr.get(cid);
      if (!cr) { add('CRITICAL', 'DB_ROW_MISSING', cid, 'correction on ledger but missing in database'); continue; }
      const cd = { corrId: cr.corr_id, originalTxId: cr.original_tx_id, correctionType: cr.correction_type, reason: cr.reason, correctedAmountMinor: cr.corrected_amount_minor, correctedNarrative: cr.corrected_narrative, salt: cr.corrected_salt };
      if (correctionHash(cd) !== c.record.correctedDataHash) add('CRITICAL', 'CORRECTION_TAMPERED', cid, 'database correction (reason/amount) no longer matches the ledger hash');
      if (cr.reason !== c.record.reason) add('CRITICAL', 'CORRECTION_REASON_MISMATCH', cid, 'correction reason differs between database and ledger');
      const cm = mirror.get(cid);
      if (!cm || cm.status !== c.status) add('WARNING', 'STATUS_MIRROR_STALE', cid, `db mirror '${cm ? cm.status : 'none'}' vs ledger '${c.status}'`);
      const cp = postingsBy.get(cid) || [];
      if (c.status === 'EXECUTED') {
        const ce = c.events.find((e) => e.eventType === 'CORRECTION_EXECUTED');
        const cx = execs.get(cid);
        if (!cx || cx.execution_hash !== ce.extra.executionHash || postingsHash(cid, cp) !== ce.extra.executionHash) add('CRITICAL', 'POSTINGS_TAMPERED', cid, 'correction postings do not match the ledger execution hash');
        if (!sameP(cp, correctionPostings(d, executedPrior, { correctionType: cd.correctionType, correctedAmountMinor: cd.correctedAmountMinor }))) add('CRITICAL', 'POSTINGS_UNEXPECTED', cid, 'correction postings differ from the expected corrective movement');
        executedPrior.push({ correctionType: cd.correctionType, correctedAmountMinor: cd.correctedAmountMinor });
      } else if (cp.length) add('CRITICAL', 'UNAUTHORISED_EXECUTION', cid, `funds moved for correction in status ${c.status}`);
    }
  }

  // ---- database rows with no ledger counterpart (injected records)
  const ledgerIds = new Set(ledgerTxs.map((t) => t.record.txId));
  for (const id of dbTx.keys()) if (!ledgerIds.has(id)) add('CRITICAL', 'DB_ROW_NOT_ON_LEDGER', id, 'database transaction has no ledger record (injected?)');
  for (const id of dbCorr.keys()) if (!seenCorr.has(id)) add('CRITICAL', 'DB_ROW_NOT_ON_LEDGER', id, 'database correction has no ledger record (injected?)');
  for (const id of postingsBy.keys()) if (!ledgerIds.has(id) && !dbCorr.has(id)) add('CRITICAL', 'ORPHAN_POSTING', id, 'postings reference an unknown transaction');

  // ---- balances: opening + sum(postings) must equal the stored balance
  for (const a of db.prepare('SELECT * FROM accounts').all()) {
    stats.accounts++;
    const s = db.prepare('SELECT COALESCE(SUM(delta_minor),0) s FROM postings WHERE account_no=?').get(a.account_no).s;
    if (a.opening_minor + s !== a.balance_minor) add('CRITICAL', 'BALANCE_TAMPERED', a.account_no, `balance ${a.balance_minor} != opening ${a.opening_minor} + postings ${s}`);
  }

  const critical = findings.filter((f) => f.severity === 'CRITICAL').length;
  const warnings = findings.length - critical;
  const report = { ranAt: new Date().toISOString(), ranBy, ok: critical === 0, critical, warnings, stats, findings };
  const summary = critical ? `${critical} CRITICAL, ${warnings} warnings` : warnings ? `OK with ${warnings} warnings` : 'OK - no anomalies';
  db.prepare('INSERT INTO integrity_runs(ran_at,ran_by,ok,summary,report) VALUES(?,?,?,?,?)').run(report.ranAt, ranBy, report.ok ? 1 : 0, summary, JSON.stringify(report));
  if (siem) {
    if (critical) siem.send('CRITICAL', 'INTEGRITY_VIOLATION', { critical, codes: [...new Set(findings.filter((f) => f.severity === 'CRITICAL').map((f) => f.code))] });
    else siem.send('INFO', 'INTEGRITY_OK', stats);
  }
  return report;
}

module.exports = { runIntegrityCheck, checkChain };
