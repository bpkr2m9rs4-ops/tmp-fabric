'use strict';
// In-process ledger for development/tests/demo: runs the REAL chaincode class against a mock stub,
// so every business rule (maker-checker, immutability, hash chain) executes exactly as on Fabric.
const path = require('path');
const cc = path.resolve(__dirname, '../../../chaincode/bank-ledger');
const { BankLedgerContract } = require(cc);
const { MockLedger } = require(path.join(cc, 'test/mock-stub.js'));

class MockLedgerAdapter {
  constructor() {
    this.ledger = new MockLedger();
    this.ledger.clock = Math.floor(Date.now() / 1000);
    this.contract = new BankLedgerContract();
    this.identities = new Map(); // label -> { identityId, mspId }
  }

  /** Create (or fetch) a pseudo-identity, as `fabric-ca-client enroll` would. */
  ensureIdentity(label, mspId) {
    if (!this.identities.has(label)) this.identities.set(label, { identityId: `x509::CN=${label}::CN=mock-ca`, mspId });
    return this.identities.get(label);
  }

  async _call(label, fn, args) {
    const id = this.identities.get(label);
    if (!id) throw new Error(`E_NO_IDENTITY: no wallet identity '${label}'`);
    const ctx = this.ledger.newCtx(id.identityId, id.mspId);
    return this.contract[fn](ctx, ...args);
  }

  submit(label, fn, ...args) { return this._call(label, fn, args).then((r) => r); }
  evaluate(label, fn, ...args) { return this._call(label, fn, args); }
  async close() {}

  /** TEST ONLY: simulates an attacker editing the world state directly (bypassing the chaincode). */
  _tamperState(key, mutate) {
    const obj = JSON.parse(this.ledger.state.get(key));
    mutate(obj);
    this.ledger.state.set(key, JSON.stringify(obj));
  }
}
module.exports = { MockLedgerAdapter };
