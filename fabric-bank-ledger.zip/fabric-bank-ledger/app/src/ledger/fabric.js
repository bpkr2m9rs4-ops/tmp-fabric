'use strict';
// Real Hyperledger Fabric adapter (Fabric Gateway client API). One wallet identity per employee:
// <wallet>/<label>/{cert.pem,key.pem,mspid}. The API acts as a custodian of employee keys (see docs/ARCHITECTURE.md).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class FabricLedgerAdapter {
  constructor(cfg) {
    this.cfg = cfg; // { peerEndpoint, peerHostAlias, tlsCertPath, channel, chaincode, contract, walletDir }
    this.client = null;
    this.gateways = new Map();
    this.sdk = require('@hyperledger/fabric-gateway');
    this.grpc = require('@grpc/grpc-js');
  }

  _grpcClient() {
    if (!this.client) {
      const tls = this.grpc.credentials.createSsl(fs.readFileSync(this.cfg.tlsCertPath));
      this.client = new this.grpc.Client(this.cfg.peerEndpoint, tls, { 'grpc.ssl_target_name_override': this.cfg.peerHostAlias });
    }
    return this.client;
  }

  _contract(label) {
    if (this.gateways.has(label)) return this.gateways.get(label).getNetwork(this.cfg.channel).getContract(this.cfg.chaincode, this.cfg.contract);
    const dir = path.join(this.cfg.walletDir, label);
    const credentials = fs.readFileSync(path.join(dir, 'cert.pem'));
    const mspId = fs.readFileSync(path.join(dir, 'mspid'), 'utf8').trim();
    const privateKey = crypto.createPrivateKey(fs.readFileSync(path.join(dir, 'key.pem')));
    const gw = this.sdk.connect({
      client: this._grpcClient(),
      identity: { mspId, credentials },
      signer: this.sdk.signers.newPrivateKeySigner(privateKey),
      evaluateOptions: () => ({ deadline: Date.now() + 5000 }),
      endorseOptions: () => ({ deadline: Date.now() + 15000 }),
      submitOptions: () => ({ deadline: Date.now() + 5000 }),
      commitStatusOptions: () => ({ deadline: Date.now() + 60000 }),
    });
    this.gateways.set(label, gw);
    return gw.getNetwork(this.cfg.channel).getContract(this.cfg.chaincode, this.cfg.contract);
  }

  ensureIdentity(label) { /* identities are created with fabric-ca-client (network/enroll-users.sh) */ return label; }

  async submit(label, fn, ...args) {
    try {
      const r = await this._contract(label).submitTransaction(fn, ...args);
      return Buffer.from(r).toString('utf8');
    } catch (e) { throw this._unwrap(e); }
  }

  async evaluate(label, fn, ...args) {
    try {
      const r = await this._contract(label).evaluateTransaction(fn, ...args);
      return Buffer.from(r).toString('utf8');
    } catch (e) { throw this._unwrap(e); }
  }

  /** Surfaces the chaincode's "E_CODE: message" text from gateway error details. */
  _unwrap(e) {
    const msg = (e.details && e.details[0] && e.details[0].message) || e.message || String(e);
    const m = /(E_[A-Z_]+: .*)$/m.exec(msg);
    return new Error(m ? m[1] : msg);
  }

  async close() { for (const g of this.gateways.values()) g.close(); if (this.client) this.client.close(); }
}
module.exports = { FabricLedgerAdapter };
