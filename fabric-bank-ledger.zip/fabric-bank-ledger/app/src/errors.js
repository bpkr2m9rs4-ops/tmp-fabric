'use strict';
class AppError extends Error {
  constructor(code, message, status) { super(`${code}: ${message}`); this.code = code; this.status = status || AppError.statusFor(code); }
  static statusFor(code) {
    if (['E_VALIDATION'].includes(code)) return 400;
    if (['E_UNAUTHENTICATED'].includes(code)) return 401;
    if (['E_NOT_AUTHORIZED', 'E_SEPARATION_OF_DUTIES', 'E_LIMIT_EXCEEDED', 'E_INACTIVE', 'E_UNREGISTERED', 'E_MSP_MISMATCH'].includes(code)) return 403;
    if (code === 'E_NOT_FOUND') return 404;
    if (['E_INVALID_STATE', 'E_DUPLICATE', 'E_IMMUTABLE', 'E_CORRECTION_IN_PROGRESS', 'E_INSUFFICIENT_FUNDS', 'E_TAMPER_DETECTED'].includes(code)) return 409;
    return 500;
  }
  /** Converts a chaincode error ("E_CODE: text") into an AppError, keeping the code. */
  static from(e) {
    if (e instanceof AppError) return e;
    const m = /(E_[A-Z_]+): (.*)$/m.exec(e.message || '');
    return m ? new AppError(m[1], m[2]) : new AppError('E_INTERNAL', e.message || String(e), 500);
  }
}
module.exports = { AppError };
