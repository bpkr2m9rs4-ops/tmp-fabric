'use strict';
// Demo/bootstrap data. Works on the mock ledger and on a real network (identities must already be enrolled
// in the wallet with the same labels - see network/enroll-users.sh).
const DEMO_PASSWORD = 'Demo@12345';

const EMPLOYEES = [
  { username: 'teller1', employeeId: 'EMP-T1', fullName: 'Teller One', role: 'TELLER' },
  { username: 'teller2', employeeId: 'EMP-T2', fullName: 'Teller Two', role: 'TELLER' },
  { username: 'approver1', employeeId: 'EMP-A1', fullName: 'Approver One (limit 5,000.00)', role: 'APPROVER', approvalLimitMinor: 500000 },
  { username: 'approver2', employeeId: 'EMP-A2', fullName: 'Approver Two (limit 50,000.00)', role: 'APPROVER', approvalLimitMinor: 5000000 },
  { username: 'senior1', employeeId: 'EMP-S1', fullName: 'Senior Approver', role: 'SENIOR_APPROVER' },
  { username: 'auditor1', employeeId: 'EMP-U1', fullName: 'Internal Auditor', role: 'AUDITOR' },
];
const ACCOUNTS = [
  { accountNo: 'LY-1001', holder: 'Customer A', currency: 'LYD', openingMinor: 1000000 },
  { accountNo: 'LY-1002', holder: 'Customer B', currency: 'LYD', openingMinor: 250000 },
  { accountNo: 'LY-1003', holder: 'Customer C', currency: 'LYD', openingMinor: 0 },
];

async function seedDemo(svc, { password = DEMO_PASSWORD } = {}) {
  await svc.bootstrap({ username: 'admin1', password, employeeId: 'EMP-ADM', fullName: 'System Administrator' });
  const admin = svc.db.prepare('SELECT * FROM users WHERE username=?').get('admin1');
  for (const e of EMPLOYEES) await svc.registerEmployee(admin, { password, ...e });
  for (const a of ACCOUNTS) svc.createAccount(a);
}
module.exports = { seedDemo, EMPLOYEES, ACCOUNTS, DEMO_PASSWORD };
