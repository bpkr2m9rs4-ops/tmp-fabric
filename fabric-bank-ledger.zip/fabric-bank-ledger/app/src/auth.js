'use strict';
const crypto = require('crypto');
const { AppError } = require('./errors');

function hashPassword(pw, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(pw, salt, 32).toString('hex') };
}
function verifyPassword(pw, salt, hash) {
  const a = Buffer.from(crypto.scryptSync(pw, salt, 32).toString('hex'));
  const b = Buffer.from(hash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const b64 = (b) => Buffer.from(b).toString('base64url');
function signToken(payload, secret, ttlSec) {
  const body = b64(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + ttlSec }));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function verifyToken(token, secret) {
  const [body, sig] = String(token || '').split('.');
  if (!body || !sig) throw new AppError('E_UNAUTHENTICATED', 'missing token');
  const exp = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  const ok = sig.length === exp.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(exp));
  if (!ok) throw new AppError('E_UNAUTHENTICATED', 'bad token');
  const p = JSON.parse(Buffer.from(body, 'base64url').toString());
  if (p.exp < Math.floor(Date.now() / 1000)) throw new AppError('E_UNAUTHENTICATED', 'token expired');
  return p;
}
module.exports = { hashPassword, verifyPassword, signToken, verifyToken };
