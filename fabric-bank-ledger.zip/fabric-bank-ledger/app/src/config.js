'use strict';
const path = require('path');
const e = process.env;
module.exports = {
  port: Number(e.PORT || 3000),
  host: e.HOST || '0.0.0.0',
  ledgerMode: e.LEDGER_MODE || 'mock', // 'mock' | 'fabric'
  dbFile: e.DB_FILE || path.join(__dirname, '../data/bank.db'),
  tokenSecret: e.TOKEN_SECRET || 'CHANGE-ME-in-production',
  tokenTtlSec: Number(e.TOKEN_TTL_SEC || 8 * 3600),
  siem: { host: e.SIEM_HOST || '', port: Number(e.SIEM_PORT || 514) }, // optional syslog (UDP) to SIEM-Collector
  fabric: {
    peerEndpoint: e.PEER_ENDPOINT || '192.168.10.12:7051',
    peerHostAlias: e.PEER_HOST_ALIAS || 'peer0.org1.example.com',
    tlsCertPath: e.PEER_TLS_CERT || path.join(__dirname, '../wallet/peer-tls-ca.pem'),
    channel: e.FABRIC_CHANNEL || 'bankchannel',
    chaincode: e.FABRIC_CHAINCODE || 'bankledger',
    contract: 'BankLedgerContract',
    walletDir: e.WALLET_DIR || path.join(__dirname, '../wallet'),
  },
};
