'use strict';
// SQLite persistence (node:sqlite, no native build needed). Holds the financial *details*;
// the ledger holds their fingerprints + the approval workflow. Append-only tables are protected
// by triggers; a privileged DB user can still bypass triggers - that is exactly what the
// integrity verifier detects (details hash != ledger hash).
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  username TEXT PRIMARY KEY, employee_id TEXT UNIQUE NOT NULL, full_name TEXT NOT NULL,
  role TEXT NOT NULL, msp_id TEXT NOT NULL, fabric_label TEXT NOT NULL,
  pw_salt TEXT NOT NULL, pw_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS accounts (
  account_no TEXT PRIMARY KEY, holder TEXT NOT NULL, currency TEXT NOT NULL,
  opening_minor INTEGER NOT NULL, balance_minor INTEGER NOT NULL CHECK (balance_minor >= 0)
);

-- Append-only: base financial details of a transaction.
CREATE TABLE IF NOT EXISTS tx_details (
  tx_id TEXT PRIMARY KEY, tx_type TEXT NOT NULL, from_account TEXT, to_account TEXT,
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0), currency TEXT NOT NULL,
  narrative TEXT NOT NULL DEFAULT '', salt TEXT NOT NULL, data_hash TEXT NOT NULL,
  created_by TEXT NOT NULL, created_at TEXT NOT NULL
);

-- Append-only: corrective records (never edit the original).
CREATE TABLE IF NOT EXISTS corrections (
  corr_id TEXT PRIMARY KEY, original_tx_id TEXT NOT NULL REFERENCES tx_details(tx_id),
  correction_type TEXT NOT NULL, reason TEXT NOT NULL,
  corrected_amount_minor INTEGER, corrected_narrative TEXT, corrected_salt TEXT NOT NULL,
  corrected_hash TEXT NOT NULL, requested_by TEXT NOT NULL, requested_at TEXT NOT NULL
);

-- Append-only: balance movements. balance = opening + SUM(delta).
CREATE TABLE IF NOT EXISTS postings (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ref_id TEXT NOT NULL, ref_kind TEXT NOT NULL CHECK (ref_kind IN ('TX','CORR')),
  account_no TEXT NOT NULL REFERENCES accounts(account_no), delta_minor INTEGER NOT NULL, posted_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_postings_ref ON postings(ref_id);

-- Append-only: execution fingerprints that were written to the ledger.
CREATE TABLE IF NOT EXISTS executions (
  ref_id TEXT PRIMARY KEY, ref_kind TEXT NOT NULL, execution_hash TEXT NOT NULL, executed_at TEXT NOT NULL
);

-- Convenience mirror of the ledger status (NOT authoritative; re-synced and cross-checked by the verifier).
CREATE TABLE IF NOT EXISTS status_mirror (
  ref_id TEXT PRIMARY KEY, ref_kind TEXT NOT NULL, status TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS integrity_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ran_at TEXT NOT NULL, ran_by TEXT NOT NULL,
  ok INTEGER NOT NULL, summary TEXT NOT NULL, report TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, username TEXT, action TEXT NOT NULL, ref_id TEXT, detail TEXT
);

${['tx_details', 'corrections', 'postings', 'executions', 'app_audit'].map((t) => `
CREATE TRIGGER IF NOT EXISTS ${t}_no_update BEFORE UPDATE ON ${t} BEGIN SELECT RAISE(ABORT, '${t} is append-only: UPDATE forbidden'); END;
CREATE TRIGGER IF NOT EXISTS ${t}_no_delete BEFORE DELETE ON ${t} BEGIN SELECT RAISE(ABORT, '${t} is append-only: DELETE forbidden'); END;`).join('\n')}
`;

function open(file = ':memory:') {
  const db = new DatabaseSync(file);
  db.exec(SCHEMA);
  return db;
}

/** Run fn inside a SQL transaction (synchronous work only). */
function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch (_) { /* ignore */ }
    throw e;
  }
}

module.exports = { open, tx };
