'use strict';
// Optional forwarding of security alerts to the SIEM-Collector node (UDP syslog, RFC 3164 style).
const dgram = require('dgram');
class Siem {
  constructor(cfg) { this.cfg = cfg; this.sock = cfg.host ? dgram.createSocket('udp4') : null; this.sent = []; }
  send(severity, event, fields) {
    const pri = severity === 'CRITICAL' ? 129 /* local0.alert */ : severity === 'WARNING' ? 132 : 134;
    const msg = `<${pri}>${new Date().toISOString()} core-banking-app bankledger: ${event} ${JSON.stringify(fields || {})}`;
    this.sent.push(msg);
    if (this.sent.length > 200) this.sent.shift();
    if (this.sock) this.sock.send(Buffer.from(msg), this.cfg.port, this.cfg.host, () => {});
  }
  close() { if (this.sock) this.sock.close(); }
}
module.exports = { Siem };
