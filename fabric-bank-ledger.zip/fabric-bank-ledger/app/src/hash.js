'use strict';
// Hash helpers. canonicalize/sha256 are byte-for-byte identical to the chaincode's lib/util.js
// (a test asserts this), so a hash computed here can be re-verified inside the ledger tooling.
const crypto = require('crypto');

function canonicalize(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(canonicalize).join(',') + ']';
  const keys = Object.keys(value).filter((k) => value[k] !== undefined).sort();
  return '{' + keys.map((k) => JSON.stringify(k) + ':' + canonicalize(value[k])).join(',') + '}';
}
const sha256 = (t) => crypto.createHash('sha256').update(t, 'utf8').digest('hex');

/** Fingerprint of the financial details kept in the database (salted: low-entropy fields can't be guessed from the ledger). */
function detailsHash(d) {
  return sha256(canonicalize({
    txId: d.txId, txType: d.txType, fromAccount: d.fromAccount || null, toAccount: d.toAccount || null,
    amountMinor: Number(d.amountMinor), currency: d.currency, narrative: d.narrative || '', salt: d.salt,
  }));
}

/** Fingerprint of the balance postings produced by an execution. */
function postingsHash(refId, postings) {
  const norm = postings
    .map((p) => ({ account: p.account, delta: Number(p.delta) }))
    .sort((a, b) => (a.account < b.account ? -1 : a.account > b.account ? 1 : a.delta - b.delta));
  return sha256(canonicalize({ refId, postings: norm }));
}

const randomSalt = () => crypto.randomBytes(16).toString('hex');
const newId = (prefix) => `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

module.exports = { canonicalize, sha256, detailsHash, postingsHash, randomSalt, newId };
