'use strict';
const { open } = require('../src/db');
const { MockLedgerAdapter } = require('../src/ledger/mock');
const { BankService } = require('../src/service');
const { Siem } = require('../src/siem');
const { seedDemo } = require('../src/seed');

async function setup() {
  const db = open();
  const ledger = new MockLedgerAdapter();
  const siem = new Siem({ host: '', port: 514 });
  const svc = new BankService({ db, ledger, siem });
  await seedDemo(svc);
  const u = (n) => db.prepare('SELECT * FROM users WHERE username=?').get(n);
  return { db, ledger, siem, svc, u };
}
/** Disable append-only triggers: simulates a DBA / attacker with direct database access. */
function dropTriggers(db) {
  for (const r of db.prepare("SELECT name FROM sqlite_master WHERE type='trigger'").all()) db.exec(`DROP TRIGGER ${r.name}`);
}
async function expectCode(p, code) {
  try { await p; } catch (e) { if (!String(e.message).includes(code)) throw new Error(`expected ${code}, got: ${e.message}`); return; }
  throw new Error(`expected ${code} but call succeeded`);
}
module.exports = { setup, dropTriggers, expectCode };
