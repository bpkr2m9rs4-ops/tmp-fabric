'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { setup, dropTriggers, expectCode } = require('./helpers');
const { runIntegrityCheck } = require('../src/integrity');
const hash = require('../src/hash');
const ccUtil = require('../../chaincode/bank-ledger/lib/util');

const bal = (db, n) => db.prepare('SELECT balance_minor b FROM accounts WHERE account_no=?').get(n).b;
const xfer = (amt = 100000) => ({ txType: 'TRANSFER', fromAccount: 'LY-1001', toAccount: 'LY-1002', amountMinor: amt, narrative: 'test' });

test('canonicalize/sha256 are identical to the chaincode implementation', () => {
  const o = { b: 1, a: [3, { z: null, y: 'x' }], c: undefined };
  assert.equal(hash.canonicalize(o), ccUtil.canonicalize(o));
  assert.equal(hash.sha256('abc'), ccUtil.sha256('abc'));
});

test('happy path: create -> approve -> execute moves money; every step is on the ledger', async () => {
  const { svc, u, db } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  assert.equal(bal(db, 'LY-1001'), 1000000, 'creation alone must not move money');
  await svc.approveTransaction(u('approver1'), txId, 'ok');
  assert.equal(bal(db, 'LY-1001'), 1000000, 'approval alone must not move money');
  const ex = await svc.executeTransaction(u('teller2'), txId);
  assert.equal(ex.status, 'EXECUTED');
  assert.equal(bal(db, 'LY-1001'), 900000);
  assert.equal(bal(db, 'LY-1002'), 350000);
  const t = await svc.getTransaction(u('auditor1'), txId);
  assert.deepEqual(t.ledger.events.map((e) => e.eventType), ['CREATED', 'APPROVED', 'EXECUTION_STARTED', 'EXECUTED']);
  assert.equal(t.ledger.events[0].actor.employeeId, 'EMP-T1');
  assert.equal(t.ledger.events[1].actor.employeeId, 'EMP-A1');
  assert.ok(t.ledger.events.every((e) => e.timestamp && e.fabricTxId));
  assert.equal(t.hashMatches, true);
});

test('NO execution before approval, and never after rejection', async () => {
  const { svc, u, db } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  await expectCode(svc.executeTransaction(u('teller1'), txId), 'E_INVALID_STATE');
  await svc.rejectTransaction(u('approver1'), txId, 'suspicious');
  await expectCode(svc.executeTransaction(u('teller1'), txId), 'E_INVALID_STATE');
  await expectCode(svc.approveTransaction(u('approver1'), txId), 'E_INVALID_STATE');
  assert.equal(bal(db, 'LY-1001'), 1000000);
});

test('double execution is impossible', async () => {
  const { svc, u, db } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  await svc.approveTransaction(u('approver1'), txId);
  await svc.executeTransaction(u('teller1'), txId);
  await expectCode(svc.executeTransaction(u('teller1'), txId), 'E_INVALID_STATE');
  assert.equal(bal(db, 'LY-1001'), 900000);
});

test('roles: teller cannot approve, approver cannot create/execute, auditor is read-only, creator != approver', async () => {
  const { svc, u } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  await expectCode(svc.approveTransaction(u('teller2'), txId), 'E_NOT_AUTHORIZED');
  await expectCode(svc.createTransaction(u('approver1'), xfer()), 'E_NOT_AUTHORIZED');
  await expectCode(svc.createTransaction(u('auditor1'), xfer()), 'E_NOT_AUTHORIZED');
  await svc.approveTransaction(u('approver1'), txId);
  await expectCode(svc.executeTransaction(u('approver1'), txId), 'E_NOT_AUTHORIZED');
  await expectCode(svc.executeTransaction(u('auditor1'), txId), 'E_NOT_AUTHORIZED');
});

test('approval limit: approver1 (limit 5,000.00) cannot approve 9,000.00; approver2 (50,000.00) can', async () => {
  const { svc, u } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer(900000));
  await expectCode(svc.approveTransaction(u('approver1'), txId), 'E_LIMIT_EXCEEDED');
  await svc.approveTransaction(u('approver2'), txId);
});

test('insufficient funds: execution fails and is recorded as EXECUTION_FAILED, no balance change', async () => {
  const { svc, u, db } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), { txType: 'WITHDRAW', fromAccount: 'LY-1002', amountMinor: 999999999 });
  await svc.approveTransaction(u('senior1'), txId);
  await expectCode(svc.executeTransaction(u('teller1'), txId), 'E_INSUFFICIENT_FUNDS');
  assert.equal(bal(db, 'LY-1002'), 250000);
  assert.equal((await svc.getTransaction(u('teller1'), txId)).ledger.status, 'EXECUTION_FAILED');
});

test('deposit and withdraw', async () => {
  const { svc, u, db } = await setup();
  const d = await svc.createTransaction(u('teller1'), { txType: 'DEPOSIT', toAccount: 'LY-1003', amountMinor: 40000 });
  const w = await svc.createTransaction(u('teller1'), { txType: 'WITHDRAW', fromAccount: 'LY-1003', amountMinor: 15000 });
  for (const id of [d.txId, w.txId]) { await svc.approveTransaction(u('approver1'), id); await svc.executeTransaction(u('teller1'), id); }
  assert.equal(bal(db, 'LY-1003'), 25000);
});

test('corrections: original is never edited; REVERSAL restores balances and links to the original', async () => {
  const { svc, u, db } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  await svc.approveTransaction(u('approver1'), txId); await svc.executeTransaction(u('teller1'), txId);
  const before = JSON.stringify(db.prepare('SELECT * FROM tx_details WHERE tx_id=?').get(txId));
  const c = await svc.requestCorrection(u('teller1'), txId, { correctionType: 'REVERSAL', reason: 'wrong beneficiary account' });
  await expectCode(svc.executeCorrection(u('teller1'), c.corrId), 'E_INVALID_STATE');          // not approved yet
  await expectCode(svc.approveCorrection(u('teller1'), c.corrId), 'E_NOT_AUTHORIZED');          // teller cannot approve
  await svc.approveCorrection(u('approver1'), c.corrId, 'confirmed');
  await svc.executeCorrection(u('teller2'), c.corrId);
  assert.equal(bal(db, 'LY-1001'), 1000000); assert.equal(bal(db, 'LY-1002'), 250000);
  assert.equal(JSON.stringify(db.prepare('SELECT * FROM tx_details WHERE tx_id=?').get(txId)), before, 'original row untouched');
  const t = await svc.getTransaction(u('auditor1'), txId);
  const corr = t.corrections[0];
  assert.equal(corr.record.originalTxId, txId);
  assert.equal(corr.record.reason, 'wrong beneficiary account');
  assert.equal(corr.record.requestedBy.employeeId, 'EMP-T1');
  assert.equal(corr.events.find((e) => e.eventType === 'CORRECTION_APPROVED').actor.employeeId, 'EMP-A1');
  await expectCode(svc.requestCorrection(u('teller1'), txId, { correctionType: 'AMEND', reason: 'again again again', correctedAmountMinor: 5 }), 'E_INVALID_STATE');
});

test('corrections: AMEND (and chained AMEND) applies only the difference; requester cannot approve own', async () => {
  const { svc, u, db } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer(100000));
  await svc.approveTransaction(u('approver1'), txId); await svc.executeTransaction(u('teller1'), txId);
  const c1 = await svc.requestCorrection(u('approver2'), txId, { correctionType: 'AMEND', reason: 'typo: amount was 700.00', correctedAmountMinor: 70000 });
  await expectCode(svc.approveCorrection(u('approver2'), c1.corrId), 'E_SEPARATION_OF_DUTIES');
  await svc.approveCorrection(u('approver1'), c1.corrId); await svc.executeCorrection(u('teller1'), c1.corrId);
  assert.equal(bal(db, 'LY-1001'), 930000); assert.equal(bal(db, 'LY-1002'), 320000);
  const c2 = await svc.requestCorrection(u('teller1'), txId, { correctionType: 'AMEND', reason: 'customer says amount was 900.00', correctedAmountMinor: 90000 });
  await svc.approveCorrection(u('approver1'), c2.corrId); await svc.executeCorrection(u('teller1'), c2.corrId);
  assert.equal(bal(db, 'LY-1001'), 910000); assert.equal(bal(db, 'LY-1002'), 340000);
  const rep = await runIntegrityCheck({ db, ledger: svc.ledger, label: 'auditor1', ranBy: 'EMP-U1' });
  assert.equal(rep.ok, true, JSON.stringify(rep.findings));
});

test('correction needs a real reason (>=10 chars) and an EXECUTED original', async () => {
  const { svc, u } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  await expectCode(svc.requestCorrection(u('teller1'), txId, { correctionType: 'REVERSAL', reason: 'long enough reason' }), 'E_INVALID_STATE');
  await svc.approveTransaction(u('approver1'), txId); await svc.executeTransaction(u('teller1'), txId);
  await expectCode(svc.requestCorrection(u('teller1'), txId, { correctionType: 'REVERSAL', reason: 'short' }), 'E_VALIDATION');
});

test('immutability: DB triggers refuse UPDATE/DELETE of financial records; chaincode refuses overwrite', async () => {
  const { svc, u, db, ledger } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  assert.throws(() => db.prepare('UPDATE tx_details SET amount_minor=1 WHERE tx_id=?').run(txId), /append-only/);
  assert.throws(() => db.prepare('DELETE FROM tx_details WHERE tx_id=?').run(txId), /append-only/);
  assert.throws(() => db.prepare('UPDATE app_audit SET action=1').run(), /append-only/);
  await expectCode(svc._submit(u('teller1'), 'CreateTransaction', txId, 'TRANSFER', 'a'.repeat(64), '5', 'LYD'), 'E_DUPLICATE');
  const h = JSON.parse(await ledger.evaluate('auditor1', 'GetRecordHistory', `TX:${txId}`));
  assert.equal(h.writes, 1);
});

test('integrity check on a clean system is OK', async () => {
  const { svc, u, db } = await setup();
  const { txId } = await svc.createTransaction(u('teller1'), xfer());
  await svc.approveTransaction(u('approver1'), txId); await svc.executeTransaction(u('teller1'), txId);
  await svc.createTransaction(u('teller1'), xfer(5000));
  const r = await runIntegrityCheck({ db, ledger: svc.ledger, label: 'auditor1', ranBy: 'EMP-U1' });
  assert.equal(r.ok, true, JSON.stringify(r.findings)); assert.equal(r.findings.length, 0);
  assert.ok(r.stats.historyKeysChecked >= 5);
});

// ------------------------------------------------------------------ tamper detection
async function executedTx(ctx) {
  const { txId } = await ctx.svc.createTransaction(ctx.u('teller1'), xfer());
  await ctx.svc.approveTransaction(ctx.u('approver1'), txId); await ctx.svc.executeTransaction(ctx.u('teller1'), txId);
  return txId;
}
const check = (ctx) => runIntegrityCheck({ db: ctx.db, ledger: ctx.svc.ledger, label: 'auditor1', ranBy: 'EMP-U1', siem: ctx.siem });
const codes = (r) => r.findings.map((f) => f.code);

test('TAMPER: DBA edits the amount in the database -> DETAILS_TAMPERED + AMOUNT_MISMATCH + SIEM alert', async () => {
  const c = await setup(); const id = await executedTx(c);
  dropTriggers(c.db); c.db.prepare('UPDATE tx_details SET amount_minor=1 WHERE tx_id=?').run(id);
  const r = await check(c);
  assert.equal(r.ok, false); assert.ok(codes(r).includes('DETAILS_TAMPERED')); assert.ok(codes(r).includes('AMOUNT_MISMATCH'));
  assert.ok(c.siem.sent.some((m) => m.includes('INTEGRITY_VIOLATION')));
});

test('TAMPER: execution is REFUSED if stored details were altered after approval', async () => {
  const c = await setup();
  const { txId } = await c.svc.createTransaction(c.u('teller1'), xfer());
  await c.svc.approveTransaction(c.u('approver1'), txId);
  dropTriggers(c.db); c.db.prepare('UPDATE tx_details SET to_account=? WHERE tx_id=?').run('LY-1003', txId);   // redirect the money
  await expectCode(c.svc.executeTransaction(c.u('teller1'), txId), 'E_TAMPER_DETECTED');
  assert.equal(bal(c.db, 'LY-1003'), 0);
  assert.ok(c.siem.sent.some((m) => m.includes('EXECUTION_BLOCKED_TAMPER')));
});

test('TAMPER: deleted DB row / injected DB row / edited balance / forged posting', async () => {
  const c = await setup(); const id = await executedTx(c);
  dropTriggers(c.db);
  c.db.prepare('DELETE FROM tx_details WHERE tx_id=?').run(id);                       // delete (FK off for the test)
  const r1 = await check(c); assert.ok(codes(r1).includes('DB_ROW_MISSING'), JSON.stringify(codes(r1)));
  c.db.prepare(`INSERT INTO tx_details VALUES('TX-FAKE-1','DEPOSIT',NULL,'LY-1003',999999,'LYD','x','s','h','EMP-T1','2026-01-01')`).run();
  c.db.prepare('UPDATE accounts SET balance_minor=balance_minor+777 WHERE account_no=?').run('LY-1003');
  c.db.prepare(`INSERT INTO postings(ref_id,ref_kind,account_no,delta_minor,posted_at) VALUES('TX-FAKE-1','TX','LY-1003',999999,'x')`).run();
  const r2 = await check(c);
  for (const k of ['DB_ROW_NOT_ON_LEDGER', 'BALANCE_TAMPERED', 'ORPHAN_POSTING']) assert.ok(codes(r2).includes(k), `${k} in ${JSON.stringify(codes(r2))}`);
});

test('TAMPER: funds moved without ledger approval is flagged UNAUTHORISED_EXECUTION', async () => {
  const c = await setup();
  const { txId } = await c.svc.createTransaction(c.u('teller1'), xfer());
  dropTriggers(c.db);
  c.db.prepare(`INSERT INTO postings(ref_id,ref_kind,account_no,delta_minor,posted_at) VALUES(?,?,?,?,?)`).run(txId, 'TX', 'LY-1001', -100000, 'x');
  c.db.prepare('UPDATE accounts SET balance_minor=balance_minor-100000 WHERE account_no=?').run('LY-1001');
  assert.ok(codes(await check(c)).includes('UNAUTHORISED_EXECUTION'));
});

test('TAMPER: postings edited after execution -> POSTINGS_TAMPERED', async () => {
  const c = await setup(); const id = await executedTx(c);
  dropTriggers(c.db); c.db.prepare('UPDATE postings SET delta_minor=delta_minor*2 WHERE ref_id=? AND delta_minor>0').run(id);
  assert.ok(codes(await check(c)).includes('POSTINGS_TAMPERED'));
});

test('TAMPER: correction reason rewritten in the DB -> CORRECTION_TAMPERED', async () => {
  const c = await setup(); const id = await executedTx(c);
  await c.svc.requestCorrection(c.u('teller1'), id, { correctionType: 'REVERSAL', reason: 'operator keyed wrong account' });
  dropTriggers(c.db); c.db.prepare("UPDATE corrections SET reason='nothing to see here'").run();
  const r = await check(c); assert.ok(codes(r).includes('CORRECTION_TAMPERED'));
});

test('TAMPER: attacker edits the ledger world-state directly (bypassing chaincode) -> chain broken', async () => {
  const c = await setup(); const id = await executedTx(c);
  c.ledger._tamperState(`EVT:${id}:0002`, (o) => { o.actor.employeeId = 'EMP-FORGED'; });       // forge who approved
  const r = await check(c); assert.ok(codes(r).includes('LEDGER_CHAIN_BROKEN'), JSON.stringify(codes(r)));
});

test('TAMPER: DB amount edited AND ledger record amount edited -> still caught (ledger dataHash fingerprint no longer matches)', async () => {
  const c = await setup(); const id = await executedTx(c);
  const newD = c.db.prepare('SELECT * FROM tx_details WHERE tx_id=?').get(id);
  dropTriggers(c.db); c.db.prepare('UPDATE tx_details SET amount_minor=5 WHERE tx_id=?').run(id);
  c.ledger._tamperState(`TX:${id}`, (o) => { o.amountMinor = 5; });
  const r = await check(c);
  assert.equal(r.ok, false);   // at least the DB hash no longer matches the (original) dataHash on the ledger
  assert.ok(codes(r).includes('DETAILS_TAMPERED'));
  assert.ok(newD);
});

test('crash recovery: transaction stuck in EXECUTING is reconciled', async () => {
  const c = await setup();
  const { txId } = await c.svc.createTransaction(c.u('teller1'), xfer());
  await c.svc.approveTransaction(c.u('approver1'), txId);
  await c.svc._submit(c.u('teller1'), 'StartExecution', txId);                         // crash right after the lock
  assert.equal((await check(c)).findings.some((f) => f.code === 'STUCK_EXECUTING'), true);
  const fixed = await c.svc.reconcileExecuting(c.u('teller1'));
  assert.deepEqual(fixed, [{ id: txId, action: 'FAILED' }]);
  assert.equal(bal(c.db, 'LY-1001'), 1000000);
});

test('deactivated employee loses ledger access immediately', async () => {
  const c = await setup();
  await c.svc.setEmployeeActive(c.u('admin1'), 'EMP-T1', false, 'left the bank');
  await expectCode(c.svc.createTransaction(c.u('teller1'), xfer()), 'E_INACTIVE');
});
