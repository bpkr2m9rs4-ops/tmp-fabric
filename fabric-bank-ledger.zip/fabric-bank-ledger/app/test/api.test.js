'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { setup } = require('./helpers');
const { createApp } = require('../src/server');

async function boot() {
  const ctx = await setup();
  const { app } = createApp({ db: ctx.db, ledger: ctx.ledger, siem: ctx.siem, secret: 'test-secret' });
  const server = await new Promise((r) => { const s = app.listen(0, '127.0.0.1', () => r(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = async (method, path, body, token) => {
    const res = await fetch(base + path, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
    return { status: res.status, body: await res.json().catch(() => null) };
  };
  const login = async (u) => (await call('POST', '/api/login', { username: u, password: 'Demo@12345' })).body.token;
  return { ...ctx, server, call, login };
}

test('HTTP: login, role-gated workflow, integrity endpoint', async () => {
  const c = await boot();
  try {
    assert.equal((await c.call('GET', '/api/transactions')).status, 401);
    assert.equal((await c.call('POST', '/api/login', { username: 'teller1', password: 'bad' })).status, 401);
    const [t, a, au] = [await c.login('teller1'), await c.login('approver1'), await c.login('auditor1')];

    const created = await c.call('POST', '/api/transactions', { txType: 'TRANSFER', fromAccount: 'LY-1001', toAccount: 'LY-1002', amountMinor: 50000, narrative: 'rent' }, t);
    assert.equal(created.status, 200); const id = created.body.txId;

    assert.equal((await c.call('POST', `/api/transactions/${id}/execute`, null, t)).status, 409, 'execute before approval refused');
    assert.equal((await c.call('POST', `/api/transactions/${id}/approve`, {}, t)).status, 403, 'teller cannot approve');
    assert.equal((await c.call('POST', `/api/transactions/${id}/approve`, { comment: 'ok' }, a)).status, 200);
    const ex = await c.call('POST', `/api/transactions/${id}/execute`, null, t);
    assert.equal(ex.status, 200); assert.equal(ex.body.status, 'EXECUTED');

    const detail = await c.call('GET', `/api/transactions/${id}`, null, au);
    assert.equal(detail.body.hashMatches, true);
    assert.equal(detail.body.ledger.events.length, 4);

    assert.equal((await c.call('POST', '/api/integrity/run', null, t)).status, 403);
    const rep = await c.call('POST', '/api/integrity/run', null, au);
    assert.equal(rep.body.ok, true);
    const accts = await c.call('GET', '/api/accounts', null, au);
    assert.equal(accts.body.find((x) => x.accountNo === 'LY-1001').balanceMinor, 950000);
  } finally { c.server.close(); }
});

test('HTTP: validation errors are 400, unknown ids 404, brute-force lockout', async () => {
  const c = await boot();
  try {
    const t = await c.login('teller1');
    assert.equal((await c.call('POST', '/api/transactions', { txType: 'TRANSFER', fromAccount: 'LY-1001', toAccount: 'LY-1001', amountMinor: 5 }, t)).status, 400);
    assert.equal((await c.call('POST', '/api/transactions', { txType: 'TRANSFER', fromAccount: 'LY-1001', toAccount: 'LY-1002', amountMinor: -5 }, t)).status, 400);
    assert.equal((await c.call('GET', '/api/transactions/NOPE-123', null, t)).status, 404);
    for (let i = 0; i < 5; i++) await c.call('POST', '/api/login', { username: 'teller2', password: 'x' });
    assert.equal((await c.call('POST', '/api/login', { username: 'teller2', password: 'Demo@12345' })).status, 429);
  } finally { c.server.close(); }
});
