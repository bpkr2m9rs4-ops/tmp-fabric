'use strict';
// End-to-end test against a REAL Fabric network (network/native/up-local.sh). Needs a FRESH network
// (Bootstrap can run once; the integrity check compares the whole ledger with this run's database).
//   E2E_FABRIC=1 RUNTIME=/path/to/fabric-run node --test --disable-warning=ExperimentalWarning test/e2e-fabric.js
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const { open } = require('../src/db');
const { BankService } = require('../src/service');
const { Siem } = require('../src/siem');
const { seedDemo } = require('../src/seed');
const { runIntegrityCheck } = require('../src/integrity');
const { FabricLedgerAdapter } = require('../src/ledger/fabric');

const RUNTIME = process.env.RUNTIME || path.join(process.env.HOME, 'fabric-run');
const skip = process.env.E2E_FABRIC !== '1' && 'set E2E_FABRIC=1 (and start network/native/up-local.sh) to run';

const cfg = {
  peerEndpoint: process.env.PEER_ENDPOINT || '127.0.0.1:7051',
  peerHostAlias: process.env.PEER_HOST_ALIAS || 'peer0.org1.example.com',
  tlsCertPath: process.env.PEER_TLS_CERT || path.join(RUNTIME, 'wallet/peer-tls-ca.pem'),
  channel: 'bankchannel', chaincode: 'bankledger', contract: 'BankLedgerContract',
  walletDir: process.env.WALLET_DIR || path.join(RUNTIME, 'wallet'),
};
async function expectCode(p, code) {
  try { await p; } catch (e) { assert.ok(String(e.message).includes(code), `expected ${code}, got: ${e.message}`); return; }
  assert.fail(`expected ${code} but call succeeded`);
}

test('Fabric end-to-end: workflow, maker-checker over real endorsement, integrity, tamper detection', { skip, timeout: 240000 }, async (t) => {
  const db = open(); const ledger = new FabricLedgerAdapter(cfg); const siem = new Siem({ host: '', port: 514 });
  const svc = new BankService({ db, ledger, siem });
  t.after(() => ledger.close());
  const u = (n) => db.prepare('SELECT * FROM users WHERE username=?').get(n);
  const bal = (n) => db.prepare('SELECT balance_minor b FROM accounts WHERE account_no=?').get(n).b;
  const xfer = (a) => ({ txType: 'TRANSFER', fromAccount: 'LY-1001', toAccount: 'LY-1002', amountMinor: a, narrative: 'e2e' });

  await seedDemo(svc);                                                    // Bootstrap + RegisterEmployee x6 on the real ledger

  const { txId } = await svc.createTransaction(u('teller1'), xfer(100000));
  await expectCode(svc.executeTransaction(u('teller1'), txId), 'E_INVALID_STATE');      // no execution before approval
  await expectCode(svc.approveTransaction(u('teller2'), txId), 'E_NOT_AUTHORIZED');     // teller cannot approve
  await expectCode(svc.approveTransaction(u('approver1'), 'NOPE-1'), 'E_NOT_FOUND');
  const big = await svc.createTransaction(u('teller1'), xfer(900000));
  await expectCode(svc.approveTransaction(u('approver1'), big.txId), 'E_LIMIT_EXCEEDED');
  await svc.approveTransaction(u('approver1'), txId, 'ok');
  assert.equal(bal('LY-1001'), 1000000);
  await svc.executeTransaction(u('teller2'), txId);
  assert.equal(bal('LY-1001'), 900000); assert.equal(bal('LY-1002'), 350000);
  await expectCode(svc.executeTransaction(u('teller1'), txId), 'E_INVALID_STATE');      // no double execution

  const d = await svc.getTransaction(u('auditor1'), txId);
  assert.deepEqual(d.ledger.events.map((e) => e.eventType), ['CREATED', 'APPROVED', 'EXECUTION_STARTED', 'EXECUTED']);
  assert.ok(d.ledger.events.every((e) => /^\d{4}-\d\d-\d\dT/.test(e.timestamp) && e.fabricTxId.length === 64));
  assert.equal(d.hashMatches, true);

  const c = await svc.requestCorrection(u('teller1'), txId, { correctionType: 'AMEND', reason: 'typo, amount was 700.00', correctedAmountMinor: 70000 });
  await expectCode(svc.approveCorrection(u('teller1'), c.corrId), 'E_NOT_AUTHORIZED');
  await svc.approveCorrection(u('approver1'), c.corrId, 'ok'); await svc.executeCorrection(u('teller1'), c.corrId);
  assert.equal(bal('LY-1001'), 930000);
  const h = JSON.parse(await ledger.evaluate('auditor1', 'GetRecordHistory', `TX:${txId}`));
  assert.equal(h.writes, 1, 'original record written exactly once on the real ledger');

  const check = () => runIntegrityCheck({ db, ledger, label: 'auditor1', ranBy: 'EMP-U1', siem });
  const clean = await check();
  assert.equal(clean.ok, true, JSON.stringify(clean.findings));
  assert.ok(clean.stats.historyKeysChecked > 10);

  for (const r of db.prepare("SELECT name FROM sqlite_master WHERE type='trigger'").all()) db.exec(`DROP TRIGGER ${r.name}`);
  db.prepare('UPDATE tx_details SET amount_minor=1 WHERE tx_id=?').run(txId);
  const bad = await check();
  assert.equal(bad.ok, false);
  assert.ok(bad.findings.some((f) => f.code === 'DETAILS_TAMPERED'));
});
