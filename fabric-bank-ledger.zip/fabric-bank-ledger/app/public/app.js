'use strict';
// Plain DOM UI (no framework). All user-controlled text is inserted with textContent => no XSS.
const $app = document.getElementById('app');
const S = { token: null, user: null, tab: 'tx', msg: null, detail: null, data: {} };
try { S.token = sessionStorage.getItem('tok'); S.user = JSON.parse(sessionStorage.getItem('usr') || 'null'); } catch (_) { /* storage unavailable */ }

const AR = {
  status: { PENDING_APPROVAL: 'بانتظار الاعتماد', APPROVED: 'معتمدة', REJECTED: 'مرفوضة', EXECUTING: 'قيد التنفيذ', EXECUTED: 'منفّذة', EXECUTION_FAILED: 'فشل التنفيذ', REQUESTED: 'مطلوب تصحيح' },
  type: { DEPOSIT: 'إيداع', WITHDRAW: 'سحب', TRANSFER: 'تحويل', REVERSAL: 'عكس كامل', AMEND: 'تعديل المبلغ' },
  role: { ADMIN: 'مدير النظام', TELLER: 'موظف عمليات', APPROVER: 'معتمِد', SENIOR_APPROVER: 'معتمِد أول', AUDITOR: 'مدقق' },
  ev: { CREATED: 'إنشاء المعاملة', APPROVED: 'اعتماد', REJECTED: 'رفض', EXECUTION_STARTED: 'بدء التنفيذ', EXECUTED: 'تم التنفيذ', EXECUTION_FAILED: 'فشل التنفيذ',
    CORRECTION_REQUESTED: 'طلب تصحيح', CORRECTION_APPROVED: 'اعتماد التصحيح', CORRECTION_REJECTED: 'رفض التصحيح', CORRECTION_EXECUTION_STARTED: 'بدء تنفيذ التصحيح', CORRECTION_EXECUTED: 'تم تنفيذ التصحيح', CORRECTION_EXECUTION_FAILED: 'فشل تنفيذ التصحيح' },
};
const money = (m, c) => `${(Number(m) / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })} ${c || ''}`.trim();
const when = (iso) => (iso ? new Date(iso).toLocaleString('en-GB') : '');

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') el.className = v; else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) el.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k.nodeType ? k : document.createTextNode(String(k)));
  return el;
}
const badge = (s) => h('span', { class: `badge ${s}` }, AR.status[s] || s);

async function api(method, path, body) {
  const res = await fetch(path, { method, headers: { 'content-type': 'application/json', ...(S.token ? { authorization: `Bearer ${S.token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const j = await res.json().catch(() => ({}));
  if (res.status === 401 && S.token) { logout(); throw new Error('انتهت الجلسة'); }
  if (!res.ok) throw new Error(`${j.error || res.status}: ${j.message || ''}`);
  return j;
}
const flash = (text, good) => { S.msg = text ? { text, good } : null; };
async function run(fn, okText) {
  try { await fn(); flash(okText, true); } catch (e) { flash(e.message, false); }
  await load(); render();
}
function logout() { S.token = null; S.user = null; try { sessionStorage.clear(); } catch (_) { /* ignore */ } render(); }

async function load() {
  if (!S.token) return;
  const r = S.user.role;
  S.data.tx = await api('GET', '/api/transactions');
  S.data.acc = await api('GET', '/api/accounts');
  S.data.corr = await api('GET', '/api/corrections');
  if (['AUDITOR', 'ADMIN'].includes(r)) { S.data.integ = await api('GET', '/api/integrity/last'); S.data.emp = await api('GET', '/api/employees'); S.data.audit = await api('GET', '/api/audit'); }
  if (S.detail) S.detail = { id: S.detail.id, ...(await api('GET', `/api/transactions/${S.detail.id}`)) };
}

// ------------------------------------------------------------------ views
function viewLogin() {
  const u = h('input', { id: 'u', autocomplete: 'username', placeholder: 'teller1' }), p = h('input', { id: 'p', type: 'password', autocomplete: 'current-password' });
  const go = async () => {
    try {
      const r = await api('POST', '/api/login', { username: u.value, password: p.value });
      S.token = r.token; S.user = r.user; try { sessionStorage.setItem('tok', r.token); sessionStorage.setItem('usr', JSON.stringify(r.user)); } catch (_) { /* ignore */ }
      flash(null); await load(); render();
    } catch (e) { flash(e.message, false); render(); }
  };
  p.addEventListener('keydown', (e) => e.key === 'Enter' && go());
  return h('div', { class: 'login card' }, h('h2', null, 'نظام توثيق المعاملات المالية'),
    h('p', { class: 'hint' }, 'Hyperledger Fabric · Maker-Checker'),
    S.msg && h('div', { class: 'msg err' }, S.msg.text),
    h('label', null, 'اسم المستخدم'), u, h('label', null, 'كلمة المرور'), p, h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: go }, 'دخول')));
}

function viewTx() {
  const rows = S.data.tx || [];
  const cnt = (s) => rows.filter((r) => r.status === s).length;
  return h('div', null,
    h('div', { class: 'card stat' }, [['الإجمالي', rows.length], ['بانتظار الاعتماد', cnt('PENDING_APPROVAL')], ['معتمدة', cnt('APPROVED')], ['منفّذة', cnt('EXECUTED')], ['مرفوضة/فاشلة', cnt('REJECTED') + cnt('EXECUTION_FAILED')]].map(([k, v]) => h('div', null, h('b', null, v), k))),
    h('div', { class: 'card' }, h('h2', null, 'المعاملات'),
      h('table', null, h('thead', null, h('tr', null, ['الرقم', 'النوع', 'المبلغ', 'من', 'إلى', 'الحالة', 'المُنشئ', 'التاريخ', 'سلامة'].map((x) => h('th', null, x)))),
        h('tbody', null, rows.map((r) => h('tr', { class: 'click', onclick: () => openDetail(r.txId) },
          h('td', { class: 'mono' }, r.txId), h('td', null, AR.type[r.txType]), h('td', null, money(r.amountMinor, r.currency)),
          h('td', { class: 'mono' }, r.fromAccount || '-'), h('td', { class: 'mono' }, r.toAccount || '-'), h('td', null, badge(r.status)),
          h('td', null, r.createdBy), h('td', null, when(r.createdAt)),
          h('td', { class: r.hashMatches && r.chainIntact ? 'ok' : 'bad' }, r.hashMatches && r.chainIntact ? '✔ سليم' : '✖ تلاعب')))))));
}

function viewNew() {
  const f = {};
  const sel = (id, opts) => (f[id] = h('select', null, opts.map(([v, t]) => h('option', { value: v }, t))));
  const inp = (id, ph, type) => (f[id] = h('input', { placeholder: ph || '', type: type || 'text' }));
  const accOpts = (S.data.acc || []).map((a) => [a.accountNo, `${a.accountNo} - ${a.holder} (${money(a.balanceMinor, a.currency)})`]);
  const type = sel('type', [['TRANSFER', 'تحويل'], ['DEPOSIT', 'إيداع'], ['WITHDRAW', 'سحب']]);
  const submit = () => run(async () => {
    const amt = f.amount.value.trim();
    if (!/^\d+(\.\d{1,2})?$/.test(amt)) throw new Error('E_VALIDATION: المبلغ غير صالح');
    const [i, d = ''] = amt.split('.');
    const r = await api('POST', '/api/transactions', { txType: type.value, fromAccount: f.from.value, toAccount: f.to.value, amountMinor: Number(i) * 100 + Number((d + '00').slice(0, 2)), narrative: f.narr.value });
    S.tab = 'tx'; flash(`تم إنشاء المعاملة ${r.txId} وهي بانتظار الاعتماد`, true);
  });
  return h('div', { class: 'card' }, h('h2', null, 'معاملة جديدة'),
    h('div', { class: 'row' }, h('div', null, h('label', null, 'النوع'), type), h('div', null, h('label', null, 'من حساب (للتحويل/السحب)'), sel('from', accOpts)),
      h('div', null, h('label', null, 'إلى حساب (للتحويل/الإيداع)'), sel('to', accOpts.slice().reverse())), h('div', null, h('label', null, 'المبلغ (بالعملة الرئيسية)'), inp('amount', '1000.00'))),
    h('label', null, 'البيان'), inp('narr', 'وصف مختصر'),
    h('p', { class: 'hint' }, 'لن يُنفَّذ أي تحويل قبل اعتماد موظف مخوّل مختلف عنك وفق حدود الصلاحية.'),
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: submit }, 'إرسال للاعتماد')));
}

function viewCorr() {
  const rows = S.data.corr || [];
  return h('div', { class: 'card' }, h('h2', null, 'السجلات التصحيحية'), h('p', { class: 'hint' }, 'السجل الأصلي لا يُعدَّل ولا يُحذف أبدًا؛ كل تصحيح سجل جديد مرتبط بالأصل.'),
    h('table', null, h('thead', null, h('tr', null, ['التصحيح', 'الأصل', 'النوع', 'السبب', 'الحالة', 'طالب التصحيح', 'المعتمِد'].map((x) => h('th', null, x)))),
      h('tbody', null, rows.map((c) => h('tr', { class: 'click', onclick: () => openDetail(c.originalTxId) }, h('td', { class: 'mono' }, c.corrId), h('td', { class: 'mono' }, c.originalTxId),
        h('td', null, AR.type[c.correctionType], c.correctedAmountMinor != null ? ` → ${money(c.correctedAmountMinor)}` : ''), h('td', null, c.reason), h('td', null, badge(c.status)), h('td', null, c.requestedBy), h('td', null, c.approvedBy || '-'))))));
}

function viewAcc() {
  return h('div', { class: 'card' }, h('h2', null, 'الحسابات'), h('table', null, h('thead', null, h('tr', null, ['الحساب', 'صاحب الحساب', 'الرصيد'].map((x) => h('th', null, x)))),
    h('tbody', null, (S.data.acc || []).map((a) => h('tr', null, h('td', { class: 'mono' }, a.accountNo), h('td', null, a.holder), h('td', null, money(a.balanceMinor, a.currency)))))));
}

function viewInteg() {
  const r = S.data.integ;
  const runIt = () => run(async () => { S.data.integ = await api('POST', '/api/integrity/run'); }, 'اكتمل الفحص');
  return h('div', null, h('div', { class: 'card' }, h('h2', null, 'اكتشاف التلاعب والتحقق من السلامة'),
    h('p', { class: 'hint' }, 'يعيد الفحص حساب سلاسل الـ Hash في الدفتر، ويتحقق أن كل سجل كُتب مرة واحدة فقط، ويقارن قاعدة البيانات بالبصمات المسجَّلة على البلوكتشين، ويعيد احتساب الأرصدة.'),
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: runIt }, 'تشغيل الفحص الآن')),
    r && h('div', null, h('div', { class: `msg ${r.ok ? 'good' : 'err'}` }, r.ok ? `✔ لا توجد مخالفات (${when(r.ranAt)})` : `✖ اكتُشفت ${r.critical} مخالفة حرجة (${when(r.ranAt)})`),
      h('div', { class: 'stat' }, Object.entries(r.stats).map(([k, v]) => h('div', null, h('b', null, v), k))),
      r.findings.length > 0 && h('table', null, h('thead', null, h('tr', null, ['الخطورة', 'الرمز', 'المرجع', 'التفصيل'].map((x) => h('th', null, x)))),
        h('tbody', null, r.findings.map((f) => h('tr', null, h('td', { class: f.severity === 'CRITICAL' ? 'bad' : 'warn' }, f.severity), h('td', { class: 'mono' }, f.code), h('td', { class: 'mono' }, f.ref), h('td', null, f.message)))))),
    !r && h('p', null, 'لم يُشغَّل أي فحص بعد.')));
}

function viewEmp() {
  const f = {};
  const mk = (id, ph, type) => (f[id] = h('input', { placeholder: ph, type: type || 'text' }));
  const role = (f.role = h('select', null, ['TELLER', 'APPROVER', 'SENIOR_APPROVER', 'AUDITOR'].map((x) => h('option', { value: x }, AR.role[x]))));
  const add = () => run(async () => {
    await api('POST', '/api/employees', { username: f.username.value, password: f.password.value, employeeId: f.employeeId.value, fullName: f.fullName.value, role: role.value, approvalLimitMinor: f.limit.value ? Math.round(Number(f.limit.value) * 100) : undefined });
  }, 'تم تسجيل الموظف على الدفتر');
  const toggle = (e) => run(() => api('POST', `/api/employees/${e.employeeId}/active`, { active: !e.active, reason: prompt('السبب (5 أحرف على الأقل)') || '' }), 'تم التحديث');
  return h('div', null, h('div', { class: 'card' }, h('h2', null, 'الموظفون المسجَّلون على الدفتر'),
    h('table', null, h('thead', null, h('tr', null, ['الرقم', 'الاسم', 'الدور', 'المنظمة', 'الحد', 'الحالة', ''].map((x) => h('th', null, x)))),
      h('tbody', null, (S.data.emp || []).map((e) => h('tr', null, h('td', { class: 'mono' }, e.employeeId), h('td', null, e.name), h('td', null, AR.role[e.role]), h('td', { class: 'mono' }, e.mspId),
        h('td', null, e.approvalLimitMinor == null ? (e.role === 'APPROVER' ? '-' : '∞') : money(e.approvalLimitMinor)), h('td', { class: e.active ? 'ok' : 'bad' }, e.active ? 'فعّال' : 'موقوف'),
        h('td', null, S.user.role === 'ADMIN' && e.role !== 'ADMIN' ? h('button', { class: 'btn sec', onclick: () => toggle(e) }, e.active ? 'إيقاف' : 'تفعيل') : '')))))),
    S.user.role === 'ADMIN' && h('div', { class: 'card' }, h('h2', null, 'تسجيل موظف جديد'),
      h('div', { class: 'row' }, h('div', null, h('label', null, 'اسم المستخدم'), mk('username', 'teller3')), h('div', null, h('label', null, 'رقم الموظف'), mk('employeeId', 'EMP-T3')),
        h('div', null, h('label', null, 'الاسم الكامل'), mk('fullName', '')), h('div', null, h('label', null, 'الدور'), role), h('div', null, h('label', null, 'حد الاعتماد (للمعتمِد)'), mk('limit', '5000.00')),
        h('div', null, h('label', null, 'كلمة المرور'), mk('password', '', 'password'))),
      h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: add }, 'تسجيل'))));
}

function viewAudit() {
  return h('div', { class: 'card' }, h('h2', null, 'سجل تدقيق التطبيق (آخر 200)'), h('table', null, h('thead', null, h('tr', null, ['الوقت', 'المستخدم', 'الإجراء', 'المرجع'].map((x) => h('th', null, x)))),
    h('tbody', null, (S.data.audit || []).map((a) => h('tr', null, h('td', null, when(a.at)), h('td', null, a.username), h('td', { class: 'mono' }, a.action), h('td', { class: 'mono' }, a.ref_id))))));
}

// ------------------------------------------------------------------ detail
async function openDetail(id) { try { S.detail = { id, ...(await api('GET', `/api/transactions/${id}`)) }; flash(null); } catch (e) { flash(e.message); } render(); }

function viewDetail() {
  const D = S.detail, L = D.ledger, d = D.details, role = S.user.role, me = S.user.employeeId;
  const act = (label, path, cls, extra) => h('button', { class: `btn ${cls || ''}`, onclick: () => run(() => api('POST', path, extra && extra()), `تم: ${label}`) }, label);
  const ask = (q) => () => ({ reason: prompt(q) || '', comment: '' });
  const btns = [];
  if (L.status === 'PENDING_APPROVAL' && ['APPROVER', 'SENIOR_APPROVER'].includes(role) && L.record.createdBy.employeeId !== me) {
    btns.push(act('اعتماد', `/api/transactions/${L.record.txId}/approve`), act('رفض', `/api/transactions/${L.record.txId}/reject`, 'danger', ask('سبب الرفض')));
  }
  if (L.status === 'APPROVED' && role === 'TELLER') btns.push(act('تنفيذ المعاملة', `/api/transactions/${L.record.txId}/execute`));
  if (L.status === 'EXECUTED' && ['TELLER', 'APPROVER', 'SENIOR_APPROVER'].includes(role)) btns.push(h('button', { class: 'btn sec', onclick: () => requestCorr(L.record.txId) }, 'طلب تصحيح'));
  return h('div', { class: 'card' },
    h('div', { class: 'actions', style: 'margin:0 0 8px' }, h('button', { class: 'btn sec', onclick: () => { S.detail = null; render(); } }, '→ رجوع')),
    h('h2', null, `معاملة ${L.record.txId} `, badge(L.status)),
    !D.hashMatches && h('div', { class: 'msg err' }, '⚠ تفاصيل قاعدة البيانات لا تطابق البصمة المسجّلة على البلوكتشين - اشتباه تلاعب. سيُرفض التنفيذ.'),
    !L.chain.intact && h('div', { class: 'msg err' }, `⚠ سلسلة الأحداث في الدفتر مكسورة: ${L.chain.error}`),
    h('dl', { class: 'kv' }, h('dt', null, 'النوع'), h('dd', null, AR.type[L.record.txType]), h('dt', null, 'المبلغ'), h('dd', null, money(L.record.amountMinor, L.record.currency)),
      h('dt', null, 'من / إلى'), h('dd', { class: 'mono' }, `${(d && d.fromAccount) || '-'} → ${(d && d.toAccount) || '-'}`), h('dt', null, 'البيان'), h('dd', null, (d && d.narrative) || ''),
      h('dt', null, 'بصمة التفاصيل (Hash)'), h('dd', { class: 'mono' }, L.record.dataHash), h('dt', null, 'تطابق DB مع الدفتر'), h('dd', { class: D.hashMatches ? 'ok' : 'bad' }, D.hashMatches ? '✔ مطابق' : '✖ غير مطابق')),
    h('div', { class: 'actions' }, btns),
    h('h3', null, 'سجل الأحداث على الدفتر (مترابط بالـ Hash)'),
    h('div', { class: 'timeline' }, L.events.map((e) => h('div', { class: 'ev' }, h('b', null, `${e.seq}. ${AR.ev[e.eventType] || e.eventType}`), ` — ${e.actor.employeeId} (${AR.role[e.actor.role] || e.actor.role}) — ${when(e.timestamp)}`,
      e.extra && (e.extra.reason || e.extra.comment) ? h('div', { class: 'hint' }, `ملاحظة: ${e.extra.reason || e.extra.comment}`) : null,
      h('div', { class: 'mono mute' }, `Fabric TxID: ${e.fabricTxId}`), h('div', { class: 'mono mute' }, `prev: ${e.prevHash.slice(0, 16)}… hash: ${e.eventHash.slice(0, 16)}…`)))),
    D.corrections.length > 0 && h('div', null, h('h3', null, 'السجلات التصحيحية المرتبطة'), D.corrections.map((c) => viewCorrBlock(c))),
    D.postings.length > 0 && h('div', null, h('h3', null, 'الحركات على الأرصدة'), h('table', null, h('tbody', null, D.postings.map((p) => h('tr', null, h('td', { class: 'mono' }, p.refId), h('td', { class: 'mono' }, p.account), h('td', { class: (p.delta < 0 ? 'bad' : 'ok') + ' num' }, money(p.delta)), h('td', null, when(p.postedAt))))))));
}

function viewCorrBlock(c) {
  const role = S.user.role, me = S.user.employeeId;
  const act = (label, path, cls, extra) => h('button', { class: `btn ${cls || ''}`, onclick: () => run(() => api('POST', path, extra && extra()), `تم: ${label}`) }, label);
  const b = [];
  if (c.status === 'REQUESTED' && ['APPROVER', 'SENIOR_APPROVER'].includes(role) && c.record.requestedBy.employeeId !== me) b.push(act('اعتماد التصحيح', `/api/corrections/${c.record.corrId}/approve`), act('رفض', `/api/corrections/${c.record.corrId}/reject`, 'danger', () => ({ reason: prompt('سبب الرفض') || '' })));
  if (c.status === 'APPROVED' && role === 'TELLER') b.push(act('تنفيذ التصحيح', `/api/corrections/${c.record.corrId}/execute`));
  return h('div', { class: 'card', style: 'background:var(--bg)' },
    h('b', { class: 'mono' }, c.record.corrId), ' ', badge(c.status), ' ', h('span', null, AR.type[c.record.correctionType], c.record.correctedAmountMinor != null ? ` → ${money(c.record.correctedAmountMinor, c.record.currency)}` : ''),
    h('div', null, `السبب: ${c.record.reason}`), h('div', { class: 'hint' }, `طالب التصحيح: ${c.record.requestedBy.employeeId} — المعتمِد: ${(c.events.find((e) => e.eventType === 'CORRECTION_APPROVED') || { actor: { employeeId: '-' } }).actor.employeeId}`),
    !c.hashMatches && h('div', { class: 'msg err' }, '⚠ بيانات التصحيح في DB لا تطابق الدفتر'), h('div', { class: 'actions' }, b));
}

function requestCorr(txId) {
  const type = h('select', null, h('option', { value: 'REVERSAL' }, 'عكس كامل للمعاملة'), h('option', { value: 'AMEND' }, 'تعديل المبلغ'));
  const amt = h('input', { placeholder: 'المبلغ الصحيح، مثال 700.00' }), reason = h('textarea', { rows: 3, placeholder: 'سبب التصحيح (10 أحرف على الأقل)' });
  const box = h('div', { class: 'card', style: 'background:var(--bg)' }, h('h3', null, 'طلب تصحيح'), h('label', null, 'النوع'), type, h('label', null, 'المبلغ الجديد (للتعديل فقط)'), amt, h('label', null, 'السبب'), reason,
    h('div', { class: 'actions' }, h('button', { class: 'btn', onclick: () => run(async () => {
      const body = { correctionType: type.value, reason: reason.value };
      if (type.value === 'AMEND') { const [i, d = ''] = amt.value.trim().split('.'); body.correctedAmountMinor = Number(i) * 100 + Number((d + '00').slice(0, 2)); }
      await api('POST', `/api/transactions/${txId}/corrections`, body);
    }, 'تم إرسال طلب التصحيح للاعتماد') }, 'إرسال')));
  document.querySelector('main .card').append(box);
}

// ------------------------------------------------------------------ shell
function render() {
  $app.replaceChildren();
  if (!S.token) { $app.append(viewLogin()); return; }
  const role = S.user.role;
  const tabs = [['tx', 'المعاملات'], ...(role === 'TELLER' ? [['new', 'معاملة جديدة']] : []), ['corr', 'التصحيحات'], ['acc', 'الحسابات'],
    ...(['AUDITOR', 'ADMIN'].includes(role) ? [['integ', 'فحص السلامة'], ['emp', 'الموظفون'], ['audit', 'سجل التطبيق']] : [])];
  const views = { tx: viewTx, new: viewNew, corr: viewCorr, acc: viewAcc, integ: viewInteg, emp: viewEmp, audit: viewAudit };
  $app.append(
    h('header', null, h('h1', null, 'نظام توثيق المعاملات المالية — Hyperledger Fabric'), h('span', { class: 'who' }, `${S.user.fullName} · ${AR.role[role]} · ${S.user.mspId}`), h('button', { class: 'btn sec', style: 'color:#fff;border-color:#fff', onclick: logout }, 'خروج')),
    h('nav', null, tabs.map(([k, t]) => h('button', { class: S.tab === k && !S.detail ? 'on' : '', onclick: () => { S.tab = k; S.detail = null; flash(null); render(); } }, t))),
    h('main', null, S.msg && h('div', { class: `msg ${S.msg.good ? 'good' : 'err'}` }, S.msg.text), S.detail ? viewDetail() : (views[S.tab] || viewTx)()));
}
(async () => { if (S.token) { try { await load(); } catch (_) { logout(); return; } } render(); })();
