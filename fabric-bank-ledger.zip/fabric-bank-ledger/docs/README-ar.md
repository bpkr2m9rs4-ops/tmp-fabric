# نظام توثيق المعاملات المالية على Hyperledger Fabric

## 1) ما الذي تم إنجازه وما حالته
| المكوّن | المسار | الحالة |
|---|---|---|
| Chaincode (Node.js) | `chaincode/bank-ledger` | مكتمل، 21 اختبار وحدة ناجح |
| API + قاعدة بيانات SQLite + كاشف التلاعب | `app/src` | مكتمل، 25 اختبارًا ناجحًا |
| الواجهة (عربي RTL) | `app/public` | مكتملة، جُرّبت في متصفح فعلي |
| عرض التلاعب | `tools/demo-tamper.js` | يعمل |
| سكربتات شبكة Fabric (بدون Docker) | `network/native` | **وضع local مُجرَّب** واجتاز اختبار e2e على Fabric حقيقي؛ وضع GNS3 لم يُجرَّب بعد |

الاختبارات تشغّل **نفس كود الـ Chaincode** فوق دفتر محاكى في الذاكرة. أما `app/test/e2e-fabric.js` فاجتاز على شبكة Fabric حقيقية (وضع local). المتبقي تجربة العقد المنفصلة على GNS3.

## 2) المعمارية
- **الدفتر (Fabric)**: يحفظ بصمة التفاصيل (SHA-256)، ومن أنشأ/اعتمد/نفّذ ومتى، وحالة المعاملة. كل سجل يُكتب مرة واحدة (`_putOnce`)، والحالة سلسلة أحداث مترابطة بالـ Hash. لا توجد في الكود أي دالة تعديل أو حذف.
- **قاعدة البيانات**: التفاصيل المالية (الحسابات، المبالغ، الأرصدة). جداولها المالية محمية بـ Triggers تمنع UPDATE/DELETE.
- **التصحيح**: سجل `CORR` جديد مرتبط بالأصل (REVERSAL أو AMEND) مع السبب وطالبه والمعتمِد؛ الأصل لا يُلمس.
- **الاعتماد**: المنشئ ≠ المعتمِد، حد اعتماد لكل معتمِد، ولا يمكن `StartExecution` إلا إذا كانت الحالة APPROVED. التطبيق يرفض التنفيذ إن لم تطابق بصمة قاعدة البيانات بصمة الدفتر.
- **المنظمات**: Org1MSP (فرع: ADMIN/TELLER)، Org2MSP (اعتماد: APPROVER/SENIOR)، Org3MSP (تدقيق: AUDITOR).
- **كشف التلاعب** (`app/src/integrity.js`): يعيد حساب سلاسل الـ Hash، ويتحقق أن كل مفتاح كُتب مرة واحدة، ويقارن DB بالدفتر، ويعيد احتساب الأرصدة، ويرسل تنبيه Syslog إلى SIEM-Collector.

## 3) التشغيل الآن (وضع المحاكاة، بدون شبكة)
```bash
cd chaincode/bank-ledger && npm install && npm test        # 21
cd ../../app && npm install && npm test                    # 25
node --disable-warning=ExperimentalWarning ../tools/demo-tamper.js   # عرض التلاعب
PORT=3000 node --disable-warning=ExperimentalWarning src/server.js   # الواجهة http://localhost:3000
```
مستخدمون تجريبيون (كلمة المرور `Demo@12345`): `admin1, teller1, teller2, approver1 (حد 5,000), approver2 (حد 50,000), senior1, auditor1`.
جرّب: `teller1` ينشئ تحويلًا ← `approver1` يعتمد ← `teller2` ينفّذ ← `auditor1` يشغّل «فحص السلامة».

## 4) التوزيع على عقد GNS3
| العقدة | العنوان | الدور المقترح |
|---|---|---|
| block_fixed | 192.168.10.11 | Orderer (المنفذ 7050) |
| block-peer-1 | 192.168.10.12 | peer0.org1 + chaincode server |
| block-peer-2 | 192.168.10.13 | peer0.org2 + chaincode server |
| block-peer-3 | 192.168.10.14 | peer0.org3 + chaincode server |
| Core-Banking-App | 192.168.30.10 | `app/` (API+واجهة+SQLite) بـ `LEDGER_MODE=fabric` |
| Core-Banking-DB | 192.168.30.11 | حاليًا غير مستخدمة؛ SQLite على Core-Banking-App. نقلها إلى PostgreSQL هناك تطوير لاحق |
| SIEM-Collector | 192.168.30.12 | يستقبل UDP/514 (`SIEM_HOST=192.168.30.12`) |

متغيرات تشغيل التطبيق على Fabric: `LEDGER_MODE=fabric PEER_ENDPOINT=192.168.10.12:7051 PEER_HOST_ALIAS=peer0.org1.example.com PEER_TLS_CERT=... WALLET_DIR=... TOKEN_SECRET=<سر طويل> SIEM_HOST=192.168.30.12`.
تهيئة الدفتر لأول مرة: تسجيل `admin1` عبر `Bootstrap` ثم باقي الموظفين (انظر `app/src/seed.js`).

## 5) تنبيه مهم: سياسة Ryu/Zero-Trust (لم أعدّل شيئًا فيها)
سياسة `zerotrust_defense_switch.py` الحالية deny-by-default، وستمنع هذه المسارات، فيجب **بموافقتك** إضافتها لاحقًا:
- Core-Banking-App (192.168.30.10) → peers 192.168.10.12-14، TCP/7051.
- Core-Banking-App ← الوصول لواجهة الويب TCP/3000 من الجهات المصرّح بها فقط (مثلًا admin-server .55 أو PCs الموظفين).
- Orderer .11 ↔ peers .12-.14: TCP/7050 وبين الأقران 7051 (gossip).
- Core-Banking-App → SIEM-Collector UDP/514 (داخل منطقة 30.x).
- Router/ACL: السماح بالمسارات بين 10.x و30.x للمنافذ أعلاه فقط.
اطلب مني صياغة التعديل المقترح (كملف منفصل للمراجعة) عند الجاهزية.

## 6) حدود يجب ذكرها أكاديميًا
- مفاتيح الموظفين محفوظة في محفظة الخادم (نموذج وصاية) لتبسيط النموذج؛ الإنتاج يحتاج توقيعًا من جهة العميل أو HSM.
- مدير قاعدة بيانات يملك صلاحيات كاملة يستطيع تجاوز Triggers؛ لذلك الحماية الحقيقية هي **الكشف** عبر البصمات على الدفتر، وليس المنع داخل DB.
- المعاملات الجديدة بين لحظة التلاعب وتشغيل الفحص لا تُكتشف إلا عند الفحص؛ يُنصح بجدولته دوريًا (cron: `tools/verify-integrity.js`).
- SQLite يعدّ `node:sqlite` تجريبيًا في Node 22.
