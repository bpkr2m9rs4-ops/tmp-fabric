'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { MockLedger } = require('./mock-stub');
const BankLedgerContract = require('../lib/bank-contract');
const { sha256, canonicalize, computeEventHash, verifyEventChain } = require('../lib/util');

const IDS = {
  admin: ['x509::CN=admin1', 'Org1MSP'],
  teller1: ['x509::CN=teller1', 'Org1MSP'],
  teller2: ['x509::CN=teller2', 'Org1MSP'],
  appr: ['x509::CN=appr1', 'Org2MSP'],        // limit 100000
  senior: ['x509::CN=senior1', 'Org2MSP'],
  auditor: ['x509::CN=auditor1', 'Org3MSP'],
  stranger: ['x509::CN=nobody', 'Org1MSP'],
};

const H = (s) => sha256(s);

function setup() {
  const ledger = new MockLedger();
  const c = new BankLedgerContract();
  const call = async (who, fn, ...args) => {
    const [id, msp] = IDS[who];
    const ctx = ledger.newCtx(id, msp);
    return c[fn](ctx, ...args);
  };
  const ok = async (who, fn, ...args) => JSON.parse(await call(who, fn, ...args));
  const bad = async (who, fn, code, ...args) => {
    await assert.rejects(() => call(who, fn, ...args), (e) => {
      assert.match(e.message, new RegExp(`^${code}:`), `expected ${code} got ${e.message}`);
      return true;
    });
  };
  return { ledger, call, ok, bad };
}

// Correct signature: RegisterEmployee(employeeId, name, role, approvalLimitMinor, identityId, mspId)
async function seed(t) {
  await t.ok('admin', 'Bootstrap', 'E001', 'Admin One');
  await t.ok('admin', 'RegisterEmployee', 'E101', 'Teller One', 'TELLER', '', IDS.teller1[0], 'Org1MSP');
  await t.ok('admin', 'RegisterEmployee', 'E102', 'Teller Two', 'TELLER', '', IDS.teller2[0], 'Org1MSP');
  await t.ok('admin', 'RegisterEmployee', 'E201', 'Approver One', 'APPROVER', '100000', IDS.appr[0], 'Org2MSP');
  await t.ok('admin', 'RegisterEmployee', 'E202', 'Senior One', 'SENIOR_APPROVER', 'UNLIMITED', IDS.senior[0], 'Org2MSP');
  await t.ok('admin', 'RegisterEmployee', 'E301', 'Auditor One', 'AUDITOR', '', IDS.auditor[0], 'Org3MSP');
}

const DATA = H('{"from":"ACC1","to":"ACC2"}');

async function createTx(t, id = 'TX-001', amount = '50000') {
  return t.ok('teller1', 'CreateTransaction', id, 'TRANSFER', DATA, amount, 'LYD');
}

// ---------------------------------------------------------------- util
test('canonicalize is deterministic regardless of key order', () => {
  assert.equal(canonicalize({ b: 1, a: { d: 2, c: 3 } }), canonicalize({ a: { c: 3, d: 2 }, b: 1 }));
});

test('verifyEventChain detects tampering', () => {
  const e1 = { seq: 1, eventType: 'CREATED', prevHash: '0'.repeat(64), x: 1 };
  e1.eventHash = computeEventHash(e1);
  const e2 = { seq: 2, eventType: 'APPROVED', prevHash: e1.eventHash, x: 2 };
  e2.eventHash = computeEventHash(e2);
  assert.equal(verifyEventChain([e1, e2]).intact, true);
  const forged = { ...e1, x: 999 };
  assert.equal(verifyEventChain([forged, e2]).intact, false);
  assert.equal(verifyEventChain([e2]).intact, false);
});

// ---------------------------------------------------------------- registry
test('bootstrap works once, only for Org1MSP', async () => {
  const t = setup();
  await t.bad('appr', 'Bootstrap', 'E_NOT_AUTHORIZED', 'E900', 'Bad Admin');
  await t.ok('admin', 'Bootstrap', 'E001', 'Admin One');
  await t.bad('admin', 'Bootstrap', 'E_ALREADY_BOOTSTRAPPED', 'E002', 'Another');
});

test('only ADMIN can register; role/organisation binding enforced', async () => {
  const t = setup();
  await t.ok('admin', 'Bootstrap', 'E001', 'Admin One');
  await t.bad('stranger', 'RegisterEmployee', 'E_UNREGISTERED', 'E9', 'X Y', 'TELLER', '', 'x509::new', 'Org1MSP');
  await t.bad('admin', 'RegisterEmployee', 'E_VALIDATION', 'E101', 'Teller', 'TELLER', '', IDS.teller1[0], 'Org2MSP');
  await t.bad('admin', 'RegisterEmployee', 'E_VALIDATION', 'E201', 'Appr', 'APPROVER', '', IDS.appr[0], 'Org2MSP'); // needs limit
  await t.ok('admin', 'RegisterEmployee', 'E101', 'Teller One', 'TELLER', '', IDS.teller1[0], 'Org1MSP');
  await t.bad('admin', 'RegisterEmployee', 'E_DUPLICATE', 'E101', 'Dup', 'TELLER', '', 'x509::other', 'Org1MSP');
  await t.bad('admin', 'RegisterEmployee', 'E_DUPLICATE', 'E102', 'Dup Id', 'TELLER', '', IDS.teller1[0], 'Org1MSP');
});

test('unregistered and deactivated identities are refused', async () => {
  const t = setup();
  await seed(t);
  await t.bad('stranger', 'CreateTransaction', 'E_UNREGISTERED', 'TX-9', 'DEPOSIT', DATA, '10', 'LYD');
  await t.ok('admin', 'SetEmployeeActive', 'E101', 'false', 'left the bank');
  await t.bad('teller1', 'CreateTransaction', 'E_INACTIVE', 'TX-9', 'DEPOSIT', DATA, '10', 'LYD');
  await t.ok('admin', 'SetEmployeeActive', 'E101', 'true', 'returned to work');
  await t.ok('teller1', 'CreateTransaction', 'TX-9', 'DEPOSIT', DATA, '10', 'LYD');
});

// ---------------------------------------------------------------- lifecycle
test('happy path: create -> approve -> execute, with identity + timestamp + hash chain', async () => {
  const t = setup();
  await seed(t);
  const r = await createTx(t);
  assert.equal(r.status, 'PENDING_APPROVAL');
  await t.ok('appr', 'ApproveTransaction', 'TX-001', 'looks fine');
  await t.ok('teller1', 'StartExecution', 'TX-001');
  await t.ok('teller1', 'ConfirmExecution', 'TX-001', H('core-banking-receipt-1'));
  const full = await t.ok('auditor', 'GetTransaction', 'TX-001');
  assert.equal(full.status, 'EXECUTED');
  assert.equal(full.record.createdBy.employeeId, 'E101');
  assert.ok(full.record.createdAt.endsWith('Z'));
  assert.equal(full.record.dataHash, DATA);
  assert.deepEqual(full.events.map((e) => e.eventType), ['CREATED', 'APPROVED', 'EXECUTION_STARTED', 'EXECUTED']);
  assert.equal(full.events[1].actor.employeeId, 'E201');
  assert.equal(full.chain.intact, true);
});

test('cannot execute before approval (core control)', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  await t.bad('teller1', 'StartExecution', 'E_INVALID_STATE', 'TX-001');
  await t.bad('teller1', 'ConfirmExecution', 'E_INVALID_STATE', 'TX-001', H('x'));
});

test('cannot execute after rejection; cannot decide twice', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  await t.bad('appr', 'RejectTransaction', 'E_VALIDATION', 'TX-001', '');
  await t.ok('appr', 'RejectTransaction', 'TX-001', 'suspicious beneficiary');
  await t.bad('teller1', 'StartExecution', 'E_INVALID_STATE', 'TX-001');
  await t.bad('senior', 'ApproveTransaction', 'E_INVALID_STATE', 'TX-001', 'x');
});

test('execution cannot be started twice (no double spending)', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  await t.ok('appr', 'ApproveTransaction', 'TX-001', '');
  await t.ok('teller1', 'StartExecution', 'TX-001');
  await t.bad('teller2', 'StartExecution', 'E_INVALID_STATE', 'TX-001');
  await t.ok('teller1', 'ConfirmExecution', 'TX-001', H('r'));
  await t.bad('teller1', 'StartExecution', 'E_INVALID_STATE', 'TX-001');
  await t.bad('teller1', 'ConfirmExecution', 'E_INVALID_STATE', 'TX-001', H('r'));
});

test('execution failure is recorded and terminal', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  await t.ok('appr', 'ApproveTransaction', 'TX-001', '');
  await t.ok('teller1', 'StartExecution', 'TX-001');
  await t.ok('teller1', 'FailExecution', 'TX-001', 'insufficient funds');
  const full = await t.ok('auditor', 'GetTransaction', 'TX-001');
  assert.equal(full.status, 'EXECUTION_FAILED');
  await t.bad('teller1', 'StartExecution', 'E_INVALID_STATE', 'TX-001');
});

test('separation of duties and role checks', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  await t.bad('teller1', 'ApproveTransaction', 'E_NOT_AUTHORIZED', 'TX-001', '');
  await t.bad('auditor', 'ApproveTransaction', 'E_NOT_AUTHORIZED', 'TX-001', '');
  await t.bad('appr', 'CreateTransaction', 'E_NOT_AUTHORIZED', 'TX-2', 'DEPOSIT', DATA, '1', 'LYD');
  await t.bad('auditor', 'CreateTransaction', 'E_NOT_AUTHORIZED', 'TX-2', 'DEPOSIT', DATA, '1', 'LYD');
  // an approver who is also registered as creator is impossible by MSP binding; verify creator!=approver via same-id guard
  await t.bad('admin', 'ApproveTransaction', 'E_NOT_AUTHORIZED', 'TX-001', '');
});

test('approval limit is enforced; senior approver unlimited', async () => {
  const t = setup();
  await seed(t);
  await createTx(t, 'TX-BIG', '5000000');
  await t.bad('appr', 'ApproveTransaction', 'E_LIMIT_EXCEEDED', 'TX-BIG', '');
  await t.ok('senior', 'ApproveTransaction', 'TX-BIG', 'ok');
});

test('input validation', async () => {
  const t = setup();
  await seed(t);
  await t.bad('teller1', 'CreateTransaction', 'E_VALIDATION', 'TX-1', 'GIFT', DATA, '10', 'LYD');
  await t.bad('teller1', 'CreateTransaction', 'E_VALIDATION', 'TX-1', 'DEPOSIT', 'nothash', '10', 'LYD');
  await t.bad('teller1', 'CreateTransaction', 'E_VALIDATION', 'TX-1', 'DEPOSIT', DATA, '-5', 'LYD');
  await t.bad('teller1', 'CreateTransaction', 'E_VALIDATION', 'TX-1', 'DEPOSIT', DATA, '0', 'LYD');
  await t.bad('teller1', 'CreateTransaction', 'E_VALIDATION', 'TX-1', 'DEPOSIT', DATA, '1.5', 'LYD');
  await t.bad('teller1', 'CreateTransaction', 'E_VALIDATION', 'TX-1', 'DEPOSIT', DATA, '10', 'lyd');
  await t.bad('teller1', 'CreateTransaction', 'E_VALIDATION', 'a', 'DEPOSIT', DATA, '10', 'LYD');
  await createTx(t, 'TX-1', '10');
  await t.bad('teller1', 'CreateTransaction', 'E_DUPLICATE', 'TX-1', 'DEPOSIT', DATA, '10', 'LYD');
});

// ---------------------------------------------------------------- immutability
test('_putOnce refuses overwrite (records can never be modified)', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  const c = new BankLedgerContract();
  const ctx = t.ledger.newCtx(...IDS.teller1);
  await assert.rejects(() => c._putOnce(ctx, 'TX:TX-001', { forged: true }), /E_IMMUTABLE/);
  await assert.rejects(() => c._putOnce(ctx, 'EVT:TX-001:0001', { forged: true }), /E_IMMUTABLE/);
});

test('no public method can update or delete financial records; history shows single write', async () => {
  const proto = Object.getOwnPropertyNames(BankLedgerContract.prototype);
  for (const m of proto) assert.ok(!/^(Update|Delete|Edit|Modify|Remove)/i.test(m), `forbidden method name ${m}`);
  const t = setup();
  await seed(t);
  await createTx(t);
  await t.ok('appr', 'ApproveTransaction', 'TX-001', '');
  for (const key of ['TX:TX-001', 'EVT:TX-001:0001', 'EVT:TX-001:0002']) {
    const h = await t.ok('auditor', 'GetRecordHistory', key);
    assert.equal(h.writes, 1, key);
    assert.equal(h.history[0].isDelete, false);
  }
  await t.bad('auditor', 'GetRecordHistory', 'E_VALIDATION', '../etc');
});

test('direct tampering of world state is detected by hash chain verification', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  await t.ok('appr', 'ApproveTransaction', 'TX-001', 'fine');
  // attacker rewrites the approver in the stored event (simulates DB/state corruption)
  const k = 'EVT:TX-001:0002';
  const e = JSON.parse(t.ledger.state.get(k));
  e.actor.employeeId = 'E999';
  t.ledger.state.set(k, JSON.stringify(e));
  const full = await t.ok('auditor', 'GetTransaction', 'TX-001');
  assert.equal(full.chain.intact, false);
  assert.match(full.chain.error, /eventHash mismatch at seq 2/);
});

// ---------------------------------------------------------------- corrections
async function executed(t, id = 'TX-001', amount = '50000') {
  await createTx(t, id, amount);
  await t.ok('appr', 'ApproveTransaction', id, '');
  await t.ok('teller1', 'StartExecution', id);
  await t.ok('teller1', 'ConfirmExecution', id, H('r-' + id));
}

test('correction creates a NEW linked record; original is untouched', async () => {
  const t = setup();
  await seed(t);
  await executed(t);
  const before = t.ledger.state.get('TX:TX-001');
  const beforeEvents = [1, 2, 3, 4].map((i) => t.ledger.state.get(`EVT:TX-001:000${i}`));
  const NEW = H('corrected-data');
  const r = await t.ok('teller1', 'RequestCorrection', 'C-001', 'TX-001', 'AMEND', 'Wrong amount typed by teller', NEW, '45000');
  assert.equal(r.status, 'REQUESTED');
  await t.ok('senior', 'ApproveCorrection', 'C-001', 'confirmed with customer');
  await t.ok('teller2', 'StartCorrectionExecution', 'C-001');
  await t.ok('teller2', 'ConfirmCorrectionExecution', 'C-001', H('r-corr'));
  const c = await t.ok('auditor', 'GetCorrection', 'C-001');
  assert.equal(c.status, 'EXECUTED');
  assert.equal(c.record.originalTxId, 'TX-001');
  assert.equal(c.record.originalDataHash, DATA);
  assert.equal(c.record.reason, 'Wrong amount typed by teller');
  assert.equal(c.record.requestedBy.employeeId, 'E101');
  assert.equal(c.events[1].actor.employeeId, 'E202');
  assert.equal(c.chain.intact, true);
  // original is byte-identical
  assert.equal(t.ledger.state.get('TX:TX-001'), before);
  [1, 2, 3, 4].forEach((i, idx) => assert.equal(t.ledger.state.get(`EVT:TX-001:000${i}`), beforeEvents[idx]));
  const list = await t.ok('auditor', 'ListCorrections', 'TX-001');
  assert.equal(list.length, 1);
});

test('correction rules: only executed txs, requester cannot approve, reason & limit enforced', async () => {
  const t = setup();
  await seed(t);
  await createTx(t);
  const NEW = H('n');
  await t.bad('teller1', 'RequestCorrection', 'E_INVALID_STATE', 'C-1', 'TX-001', 'REVERSAL', 'duplicate payment entry', NEW, '');
  await t.ok('appr', 'ApproveTransaction', 'TX-001', '');
  await t.ok('teller1', 'StartExecution', 'TX-001');
  await t.ok('teller1', 'ConfirmExecution', 'TX-001', H('r'));
  await t.bad('teller1', 'RequestCorrection', 'E_VALIDATION', 'C-1', 'TX-001', 'REVERSAL', 'short', NEW, '');
  await t.bad('teller1', 'RequestCorrection', 'E_VALIDATION', 'C-1', 'TX-001', 'AMEND', 'amount typed wrongly', NEW, '');
  await t.bad('auditor', 'RequestCorrection', 'E_NOT_AUTHORIZED', 'C-1', 'TX-001', 'REVERSAL', 'duplicate payment entry', NEW, '');
  await t.ok('appr', 'RequestCorrection', 'C-1', 'TX-001', 'REVERSAL', 'duplicate payment entry', NEW, '');
  await t.bad('appr', 'ApproveCorrection', 'E_SEPARATION_OF_DUTIES', 'C-1', '');
  await t.bad('teller1', 'RequestCorrection', 'E_CORRECTION_IN_PROGRESS', 'C-2', 'TX-001', 'REVERSAL', 'another attempt here', NEW, '');
  await t.bad('teller1', 'StartCorrectionExecution', 'E_INVALID_STATE', 'C-1');
  await t.ok('senior', 'RejectCorrection', 'C-1', 'not a duplicate');
  // after rejection a new request is allowed and links independently
  await t.ok('teller1', 'RequestCorrection', 'C-2', 'TX-001', 'REVERSAL', 'confirmed duplicate payment', NEW, '');
});

test('correction approval limit uses max(original, corrected) exposure', async () => {
  const t = setup();
  await seed(t);
  await executed(t, 'TX-001', '90000');
  await t.ok('teller1', 'RequestCorrection', 'C-1', 'TX-001', 'AMEND', 'actual amount was larger', H('n'), '900000');
  await t.bad('appr', 'ApproveCorrection', 'E_LIMIT_EXCEEDED', 'C-1', '');
  await t.ok('senior', 'ApproveCorrection', 'C-1', '');
});

test('fully reversed transaction cannot be corrected again; amended can be amended again (chain)', async () => {
  const t = setup();
  await seed(t);
  await executed(t);
  await t.ok('teller1', 'RequestCorrection', 'C-1', 'TX-001', 'AMEND', 'first amendment of amount', H('a'), '40000');
  await t.ok('appr', 'ApproveCorrection', 'C-1', '');
  await t.ok('teller1', 'StartCorrectionExecution', 'C-1');
  await t.ok('teller1', 'ConfirmCorrectionExecution', 'C-1', H('r1'));
  const r2 = await t.ok('teller1', 'RequestCorrection', 'C-2', 'TX-001', 'REVERSAL', 'cancel whole operation', H('b'), '');
  assert.equal(r2.status, 'REQUESTED');
  const c2 = await t.ok('auditor', 'GetCorrection', 'C-2');
  assert.equal(c2.record.previousCorrectionId, 'C-1');
  await t.ok('appr', 'ApproveCorrection', 'C-2', '');
  await t.ok('teller1', 'StartCorrectionExecution', 'C-2');
  await t.ok('teller1', 'ConfirmCorrectionExecution', 'C-2', H('r2'));
  await t.bad('teller1', 'RequestCorrection', 'E_INVALID_STATE', 'C-3', 'TX-001', 'REVERSAL', 'cancel yet again', H('c'), '');
});

test('queries: list transactions and employee access control', async () => {
  const t = setup();
  await seed(t);
  await createTx(t, 'TX-001');
  await createTx(t, 'TX-002', '10');
  const list = await t.ok('auditor', 'ListTransactions');
  assert.equal(list.length, 2);
  assert.ok(list.every((x) => x.chain.intact));
  await t.bad('teller1', 'ListEmployees', 'E_NOT_AUTHORIZED');
  const emps = await t.ok('auditor', 'ListEmployees');
  assert.equal(emps.length, 6);
  const me = await t.ok('teller1', 'GetMyProfile');
  assert.equal(me.employeeId, 'E101');
  await t.bad('teller1', 'GetEmployee', 'E_NOT_AUTHORIZED', 'E201');
});
