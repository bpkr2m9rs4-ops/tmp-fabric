'use strict';
// Minimal in-memory simulation of the Fabric chaincode stub + client identity,
// sufficient for unit-testing business rules (ordering of keys follows lexicographic range semantics).

class MockLedger {
  constructor() {
    this.state = new Map();
    this.history = new Map(); // key -> [{txId, timestamp, isDelete}]
    this.txCounter = 0;
    this.clock = 1_700_000_000;
  }

  newCtx(identityId, mspId) {
    this.txCounter += 1;
    this.clock += 5;
    const ledger = this;
    const txId = `fabtx${String(this.txCounter).padStart(6, '0')}`;
    const ts = { seconds: ledger.clock, nanos: 0 };
    const stub = {
      getTxID: () => txId,
      getTxTimestamp: () => ts,
      async getState(key) {
        return ledger.state.has(key) ? Buffer.from(ledger.state.get(key)) : Buffer.alloc(0);
      },
      async putState(key, value) {
        ledger.state.set(key, Buffer.from(value).toString('utf8'));
        if (!ledger.history.has(key)) ledger.history.set(key, []);
        ledger.history.get(key).push({ txId, timestamp: ts, isDelete: false });
      },
      async deleteState(key) {
        ledger.state.delete(key);
        if (!ledger.history.has(key)) ledger.history.set(key, []);
        ledger.history.get(key).push({ txId, timestamp: ts, isDelete: true });
      },
      async getStateByRange(start, end) {
        const keys = [...ledger.state.keys()].filter((k) => k >= start && k < end).sort();
        let i = 0;
        return {
          async next() {
            if (i < keys.length) {
              const k = keys[i++];
              return { value: { key: k, value: Buffer.from(ledger.state.get(k)) }, done: false };
            }
            return { value: undefined, done: true };
          },
          async close() {},
        };
      },
      async getHistoryForKey(key) {
        const h = ledger.history.get(key) || [];
        let i = 0;
        return {
          async next() {
            if (i < h.length) return { value: h[i++], done: false };
            return { value: undefined, done: true };
          },
          async close() {},
        };
      },
    };
    const clientIdentity = { getID: () => identityId, getMSPID: () => mspId };
    return { stub, clientIdentity };
  }
}

module.exports = { MockLedger };
