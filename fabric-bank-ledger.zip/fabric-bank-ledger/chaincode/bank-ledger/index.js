'use strict';

const BankLedgerContract = require('./lib/bank-contract');
const constants = require('./lib/constants');
const util = require('./lib/util');

module.exports.BankLedgerContract = BankLedgerContract;
module.exports.contracts = [BankLedgerContract];
module.exports.constants = constants;
module.exports.util = util;
