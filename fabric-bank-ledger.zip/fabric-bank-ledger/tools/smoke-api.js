'use strict';
// End-to-end smoke test over HTTP against a running server. Usage: node smoke-api.js [http://127.0.0.1:3000]
const base = process.argv[2] || 'http://127.0.0.1:3000';
const call = async (m, p, b, t) => {
  const r = await fetch(base + p, { method: m, headers: { 'content-type': 'application/json', ...(t ? { authorization: 'Bearer ' + t } : {}) }, body: b ? JSON.stringify(b) : undefined });
  return { status: r.status, body: await r.json().catch(() => ({})) };
};
const login = async (u) => (await call('POST', '/api/login', { username: u, password: 'Demo@12345' })).body.token;
const step = (name, ok, extra) => { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) process.exitCode = 1; };
(async () => {
  const [t1, t2, a1, au] = [await login('teller1'), await login('teller2'), await login('approver1'), await login('auditor1')];
  step('login of 4 users', !!(t1 && t2 && a1 && au));
  const c = await call('POST', '/api/transactions', { txType: 'TRANSFER', fromAccount: 'LY-1001', toAccount: 'LY-1002', amountMinor: 100000, narrative: 'smoke test' }, t1);
  step('teller1 creates transfer', c.status === 200, c.body.txId);
  const id = c.body.txId;
  step('execute BEFORE approval is refused', (await call('POST', `/api/transactions/${id}/execute`, null, t1)).status === 409);
  step('teller cannot approve', (await call('POST', `/api/transactions/${id}/approve`, {}, t2)).status === 403);
  step('approver1 approves', (await call('POST', `/api/transactions/${id}/approve`, { comment: 'ok' }, a1)).status === 200);
  const ex = await call('POST', `/api/transactions/${id}/execute`, null, t2);
  step('teller2 executes', ex.status === 200 && ex.body.status === 'EXECUTED');
  step('second execution refused', (await call('POST', `/api/transactions/${id}/execute`, null, t2)).status === 409);
  const d = await call('GET', `/api/transactions/${id}`, null, au);
  step('ledger has 4 hash-chained events', d.body.ledger && d.body.ledger.events.length === 4 && d.body.hashMatches === true);
  const cr = await call('POST', `/api/transactions/${id}/corrections`, { correctionType: 'AMEND', reason: 'smoke test: amount was 700.00', correctedAmountMinor: 70000 }, t1);
  step('correction record requested', cr.status === 200, cr.body.corrId);
  step('teller cannot approve correction', (await call('POST', `/api/corrections/${cr.body.corrId}/approve`, {}, t1)).status === 403);
  await call('POST', `/api/corrections/${cr.body.corrId}/approve`, { comment: 'ok' }, a1);
  step('correction executed', (await call('POST', `/api/corrections/${cr.body.corrId}/execute`, null, t1)).status === 200);
  const rep = await call('POST', '/api/integrity/run', null, au);
  step('integrity check clean', rep.body.ok === true, JSON.stringify(rep.body.stats));
})().catch((e) => { console.error(e); process.exit(1); });
