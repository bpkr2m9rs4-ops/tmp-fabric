'use strict';
// One-time initialisation of a REAL Fabric ledger + the app database.
// Usage: LEDGER_MODE=fabric DB_FILE=/root/bank.db PEER_ENDPOINT=... WALLET_DIR=... PEER_TLS_CERT=... node init-fabric.js
const fs = require('fs');
const path = require('path');
const cfg = require('../app/src/config');
const { open } = require('../app/src/db');
const { buildLedger } = require('../app/src/server');
const { BankService } = require('../app/src/service');
const { seedDemo } = require('../app/src/seed');
(async () => {
  fs.mkdirSync(path.dirname(cfg.dbFile), { recursive: true });
  const ledger = buildLedger();
  const svc = new BankService({ db: open(cfg.dbFile), ledger });
  await seedDemo(svc);
  console.log('init OK: admin + 6 employees registered on the ledger, 3 demo accounts created in', cfg.dbFile);
  await ledger.close();
  process.exit(0);
})().catch((e) => { console.error('INIT FAILED:', e.message); process.exit(1); });
