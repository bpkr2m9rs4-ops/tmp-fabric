#!/usr/bin/env node
'use strict';
// Self-contained academic demo (in-memory ledger running the real chaincode): clean run -> attack -> detection.
const { open } = require('../app/src/db');
const { MockLedgerAdapter } = require('../app/src/ledger/mock');
const { BankService } = require('../app/src/service');
const { seedDemo } = require('../app/src/seed');
const { runIntegrityCheck } = require('../app/src/integrity');
(async () => {
  const db = open(); const ledger = new MockLedgerAdapter(); const svc = new BankService({ db, ledger });
  await seedDemo(svc);
  const u = (n) => db.prepare('SELECT * FROM users WHERE username=?').get(n);
  const { txId } = await svc.createTransaction(u('teller1'), { txType: 'TRANSFER', fromAccount: 'LY-1001', toAccount: 'LY-1002', amountMinor: 100000, narrative: 'demo' });
  await svc.approveTransaction(u('approver1'), txId); await svc.executeTransaction(u('teller1'), txId);
  const show = async (t) => { const r = await runIntegrityCheck({ db, ledger, label: 'auditor1', ranBy: 'demo' }); console.log(`\n== ${t}: ${r.ok ? 'OK' : 'VIOLATION'}`); r.findings.forEach((f) => console.log(`  [${f.severity}] ${f.code} ${f.ref} - ${f.message}`)); };
  await show('1) clean system');
  for (const r of db.prepare("SELECT name FROM sqlite_master WHERE type='trigger'").all()) db.exec(`DROP TRIGGER ${r.name}`); // attacker with DBA rights
  db.prepare('UPDATE tx_details SET amount_minor=1 WHERE tx_id=?').run(txId);
  await show('2) attacker edits amount in DB');
  ledger._tamperState(`EVT:${txId}:0002`, (o) => { o.actor.employeeId = 'EMP-FORGED'; });
  await show('3) attacker also forges the approver on the ledger state');
})();
