#!/usr/bin/env node
'use strict';
// Usage: LEDGER_MODE=fabric DB_FILE=app/data/bank.db node tools/verify-integrity.js [auditorLabel]
// Exit code 0 = clean, 2 = tampering detected. Run from cron on the SIEM/audit side.
const cfg = require('../app/src/config');
const { open } = require('../app/src/db');
const { buildLedger } = require('../app/src/server');
const { Siem } = require('../app/src/siem');
const { runIntegrityCheck } = require('../app/src/integrity');
(async () => {
  const label = process.argv[2] || 'auditor1';
  const r = await runIntegrityCheck({ db: open(cfg.dbFile), ledger: buildLedger(), label, siem: new Siem(cfg.siem), ranBy: label });
  console.log(JSON.stringify(r, null, 2));
  process.exit(r.ok ? 0 : 2);
})().catch((e) => { console.error(e.message); process.exit(1); });
